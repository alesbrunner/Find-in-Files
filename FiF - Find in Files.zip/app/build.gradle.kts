plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "cz.fif.findinfiles"
    compileSdk = 36

    defaultConfig {
        applicationId = "cz.fif.findinfiles"
        minSdk = 26
        targetSdk = 36
        versionCode = 32
        versionName = "1.31"
        // OCR knihovna obsahuje nativní kód – stačí běžné mobily (ARM), APK je pak menší
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // Vlastní podpisový klíč – díky němu jde každá nová verze nainstalovat přes starou.
    signingConfigs {
        create("own") {
            storeFile = file("dochledac.jks")
            storePassword = "dochledac"
            keyAlias = "dochledac"
            keyPassword = "dochledac"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("own")
        }
        debug {
            signingConfig = signingConfigs.getByName("own")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES", "META-INF/versions/9/OSGI-INF/MANIFEST.MF",
                "META-INF/versions/9/module-info.class", "META-INF/INDEX.LIST",
                "META-INF/LICENSE", "META-INF/LICENSE.txt", "META-INF/NOTICE", "META-INF/NOTICE.txt",
            )
        }
    }
    // APK se jmenuje „FiF - Find in Files <verze>.apk“
    applicationVariants.all {
        val variant = this
        outputs.all {
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl).outputFileName =
                "FiF - Find in Files ${variant.versionName}.apk"
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.work:work-runtime-ktx:2.10.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // síťová úložiště: SMB (NAS) – šifrování z Bouncy Castle už přináší pdfbox, proto se nepřidává podruhé
    implementation("com.hierynomus:smbj:0.13.0") {
        exclude(group = "org.bouncycastle")
    }
    // WebDAV přes https
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
