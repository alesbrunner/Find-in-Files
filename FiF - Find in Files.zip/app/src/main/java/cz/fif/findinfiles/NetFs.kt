package cz.fif.findinfiles

import android.util.Xml
import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.msfscc.FileAttributes
import com.hierynomus.mssmb2.SMB2CreateDisposition
import com.hierynomus.mssmb2.SMB2ImpersonationLevel
import com.hierynomus.mssmb2.SMB2ShareAccess
import com.hierynomus.security.bc.BCSecurityProvider
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.SmbConfig
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.connection.Connection
import com.hierynomus.smbj.session.Session
import com.hierynomus.smbj.share.DiskShare
import com.hierynomus.smbj.share.PipeShare
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.HostKey
import com.jcraft.jsch.HostKeyRepository
import com.jcraft.jsch.JSch
import com.jcraft.jsch.JSchException
import com.jcraft.jsch.UserInfo
import okhttp3.Credentials
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyStore
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.EnumSet
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLException
import javax.net.ssl.TrustManager
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

// ---------------------------------------------------------------- Samba

/** NAS přes SMB 2/3 (Windows sdílení, QNAP, Synology…). */
class SmbFs(s: NetServer) : RemoteFs {
    companion object {
        private val client: SMBClient by lazy {
            SMBClient(
                SmbConfig.builder()
                    .withTimeout(30, TimeUnit.SECONDS)
                    .withSoTimeout(20, TimeUnit.SECONDS)
                    .withMultiProtocolNegotiate(true)
                    .withSecurityProvider(BCSecurityProvider())
                    .build()
            )
        }
    }

    private val conn: Connection
    private val session: Session
    /** Starší úložiště mají jednu pevnou sdílenou složku; nová začínají seznamem sdílených složek. */
    private val fixedShare: String? = s.share.trim('/', '\\').ifEmpty { null }
    private val shares = HashMap<String, DiskShare>()

    init {
        val host = s.host.substringBefore(':').trim()
        val port = s.host.substringAfter(':', "").toIntOrNull() ?: 445
        conn = client.connect(host, port)
        try {
            val auth = if (s.user.isBlank()) AuthenticationContext.guest() else {
                val domain = if (s.user.contains('\\')) s.user.substringBefore('\\') else ""
                val user = s.user.substringAfter('\\')
                AuthenticationContext(user, s.pass.toCharArray(), domain)
            }
            session = conn.authenticate(auth)
            fixedShare?.let { disk(it) }
        } catch (e: Throwable) {
            close()
            throw e
        }
    }

    private fun disk(name: String): DiskShare = shares.getOrPut(name.lowercase()) {
        session.connectShare(name) as? DiskShare ?: throw IOException("Not a disk share")
    }

    /** (sdílená složka, cesta uvnitř ve tvaru Windows) – null = kořen se seznamem sdílených složek. */
    private fun split(path: String): Pair<String?, String> {
        val p = path.trim('/')
        if (fixedShare != null) return fixedShare to p.replace('/', '\\')
        if (p.isEmpty()) return null to ""
        return p.substringBefore('/') to p.substringAfter('/', "").replace('/', '\\')
    }

    override fun list(path: String): List<RemoteEntry> {
        val (sh, sub) = split(path)
        if (sh == null) {
            val names = try {
                SrvSvc.shares(session)
            } catch (e: Throwable) {
                throw SharesUnavailable(e)
            }
            return names.map { RemoteEntry(it, true, 0L, 0L) }
        }
        return disk(sh).list(sub).filter { it.fileName != "." && it.fileName != ".." }.map {
            RemoteEntry(
                it.fileName,
                (it.fileAttributes and FileAttributes.FILE_ATTRIBUTE_DIRECTORY.value) != 0L,
                it.endOfFile,
                it.lastWriteTime.toEpochMillis(),
            )
        }
    }

    override fun open(path: String): RemoteFile {
        val (sh, sub) = split(path)
        if (sh == null) throw IOException("Not a file")
        val f = disk(sh).openFile(
            sub, EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL,
            SMB2CreateDisposition.FILE_OPEN, null,
        )
        val total = f.fileInformation.standardInformation.endOfFile
        return object : RemoteFile {
            override val size = total
            override fun read(offset: Long, buf: ByteArray, off: Int, len: Int): Int = f.read(buf, offset, off, len)
            override fun close() = f.close()
        }
    }

    override fun close() {
        val all = ArrayList<AutoCloseable>(shares.values)
        try {
            all.add(session)
        } catch (e: Throwable) {
        }
        try {
            all.add(conn)
        } catch (e: Throwable) {
        }
        for (c in all) try {
            c.close()
        } catch (e: Exception) {
        }
    }
}

/**
 * Seznam sdílených složek (služba „srvsvc“, volání NetrShareEnum úrovně 1) přes pojmenovanou rouru IPC$.
 * Ruční DCE/RPC – stačí jedno volání, celá RPC knihovna by byla zbytečně velká.
 */
object SrvSvc {
    private const val SRVSVC = "4b324fc8-1670-01d3-1278-5a47bf6ee188"
    private const val NDR = "8a885d04-1ceb-11c9-9fe8-08002b104860"

    fun shares(session: Session): List<String> {
        val ipc = session.connectShare("IPC\$") as? PipeShare ?: throw IOException("IPC$")
        try {
            val pipe = ipc.open(
                "srvsvc", SMB2ImpersonationLevel.Impersonation, EnumSet.of(AccessMask.MAXIMUM_ALLOWED),
                null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null,
            )
            try {
                pipe.write(bind())
                val ack = readPdu(pipe)
                if (ack.isEmpty() || ack[2].toInt() != 12) throw IOException("bind rejected")
                pipe.write(request())
                return parse(readStub(pipe))
            } finally {
                pipe.close()
            }
        } finally {
            ipc.close()
        }
    }

    private fun le(n: Int) = ByteBuffer.allocate(n).order(ByteOrder.LITTLE_ENDIAN)

    private fun putUuid(b: ByteBuffer, uuid: String) {
        val p = uuid.split('-')
        b.putInt(p[0].toLong(16).toInt())
        b.putShort(p[1].toInt(16).toShort())
        b.putShort(p[2].toInt(16).toShort())
        val rest = p[3] + p[4]
        for (i in 0 until 8) b.put(rest.substring(i * 2, i * 2 + 2).toInt(16).toByte())
    }

    private fun header(b: ByteBuffer, type: Int, len: Int) {
        b.put((5).toByte()); b.put((0).toByte()); b.put(type.toByte()); b.put((3).toByte())
        b.put((0x10).toByte()); b.put((0).toByte()); b.put((0).toByte()); b.put((0).toByte())
        b.putShort(len.toShort()); b.putShort((0).toShort()); b.putInt(1)
    }

    private fun bind(): ByteArray {
        val b = le(72)
        header(b, 11, 72)
        b.putShort((4280).toShort()); b.putShort((4280).toShort()); b.putInt(0)
        b.put((1).toByte()); b.put((0).toByte()); b.putShort((0).toShort())
        b.putShort((0).toShort()); b.put((1).toByte()); b.put((0).toByte())
        putUuid(b, SRVSVC); b.putShort((3).toShort()); b.putShort((0).toShort())
        putUuid(b, NDR); b.putInt(2)
        return b.array()
    }

    private fun request(): ByteArray {
        val stub = le(36)
        stub.putInt(0) // název serveru: nevyplněno
        stub.putInt(1); stub.putInt(1); stub.putInt(0x20004) // úroveň 1, ukazatel na kontejner
        stub.putInt(0); stub.putInt(0) // kontejner: 0 položek, bez pole
        stub.putInt(-1) // bez omezení délky
        stub.putInt(0x20008); stub.putInt(0) // resume handle
        val len = 24 + 36
        val b = le(len)
        header(b, 0, len)
        b.putInt(36); b.putShort((0).toShort()); b.putShort((15).toShort()) // alloc hint, kontext, opnum NetrShareEnum
        b.put(stub.array())
        return b.array()
    }

    private val pending = ByteArrayOutputStream()

    /** Jeden celý PDU (roura může vrátit víc fragmentů najednou). */
    private fun readPdu(pipe: com.hierynomus.smbj.share.NamedPipe): ByteArray {
        val buf = ByteArray(65536)
        while (true) {
            val have = pending.toByteArray()
            if (have.size >= 10) {
                val len = (have[8].toInt() and 0xFF) or ((have[9].toInt() and 0xFF) shl 8)
                if (have.size >= len) {
                    pending.reset()
                    pending.write(have, len, have.size - len)
                    return have.copyOf(len)
                }
            }
            val n = pipe.read(buf)
            if (n <= 0) throw IOException("pipe closed")
            pending.write(buf, 0, n)
        }
    }

    private fun readStub(pipe: com.hierynomus.smbj.share.NamedPipe): ByteArray {
        val out = ByteArrayOutputStream()
        while (true) {
            val pdu = readPdu(pipe)
            if (pdu[2].toInt() != 2) throw IOException("rpc fault")
            out.write(pdu, 24, pdu.size - 24)
            if ((pdu[3].toInt() and 2) != 0) break // poslední fragment
        }
        pending.reset()
        return out.toByteArray()
    }

    private fun parse(stub: ByteArray): List<String> {
        val b = ByteBuffer.wrap(stub).order(ByteOrder.LITTLE_ENDIAN)
        b.int; b.int; b.int // úroveň, přepínač, ukazatel na kontejner
        val entries = b.int
        val arrPtr = b.int
        if (arrPtr == 0 || entries == 0) return emptyList()
        val count = b.int
        val names = IntArray(count)
        val types = IntArray(count)
        val remarks = IntArray(count)
        for (i in 0 until count) {
            names[i] = b.int; types[i] = b.int; remarks[i] = b.int
        }
        fun str(): String {
            b.int; b.int
            val actual = b.int
            val chars = CharArray(actual) { b.short.toInt().toChar() }
            while (b.position() % 4 != 0) b.get()
            return String(chars).trimEnd('\u0000')
        }
        val out = ArrayList<String>()
        for (i in 0 until count) {
            val name = if (names[i] != 0) str() else ""
            if (remarks[i] != 0) str()
            val t = types[i]
            // jen běžné diskové sdílené složky (ne tiskárny, IPC$, skryté C$…)
            if ((t and 0x0FFFFFFF) == 0 && (t and 0x80000000.toInt()) == 0 && name.isNotEmpty() && !name.endsWith("$")) {
                out.add(name)
            }
        }
        return out.sortedBy { it.lowercase() }
    }
}

// ---------------------------------------------------------------- WebDAV

class DavHttpException(val code: Int) : IOException("HTTP $code")

/** WebDAV přes https (QNAP, Synology, Nextcloud…). Heslo jde jen šifrovaným spojením. */
class DavFs(private val s: NetServer) : RemoteFs {
    companion object {
        private val PROPFIND_BODY = """<?xml version="1.0" encoding="utf-8"?>
<d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/><d:getcontentlength/><d:getlastmodified/></d:prop></d:propfind>"""

        private val systemTrust: X509TrustManager by lazy {
            val f = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
            f.init(null as KeyStore?)
            f.trustManagers.filterIsInstance<X509TrustManager>().first()
        }
    }

    /** Otisk certifikátu, kterým se server naposledy představil (pro dotaz „Důvěřovat?“). */
    @Volatile var seenFingerprint: String? = null
        private set

    /**
     * Certifikát ověří systém; když ho nezná (domácí NAS s vlastním certifikátem), projde jen ten,
     * kterému uživatel výslovně důvěřoval (shoda otisku).
     */
    private val trust = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<out X509Certificate>, authType: String) =
            systemTrust.checkClientTrusted(chain, authType)

        override fun checkServerTrusted(chain: Array<out X509Certificate>, authType: String) {
            val fp = Net.sha256(chain[0].encoded)
            seenFingerprint = fp
            if (s.pin.isNotEmpty() && fp == s.pin) return
            systemTrust.checkServerTrusted(chain, authType)
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = systemTrust.acceptedIssuers
    }

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .sslSocketFactory(SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(trust), null) }.socketFactory, trust)
        .hostnameVerifier { host, session ->
            // ověřený název serveru, nebo certifikát, kterému uživatel důvěřuje (NAS na IP adrese)
            HttpsURLConnection.getDefaultHostnameVerifier().verify(host, session) ||
                (s.pin.isNotEmpty() && try {
                    Net.sha256(session.peerCertificates[0].encoded) == s.pin
                } catch (e: Exception) {
                    false
                })
        }
        .build()

    /** Chyba zabezpečeného spojení → dotaz na důvěru v certifikát. */
    private inline fun <T> guarded(block: () -> T): T = try {
        block()
    } catch (e: SSLException) {
        val fp = seenFingerprint ?: throw e
        throw TrustNeeded(fp, changed = s.pin.isNotEmpty() && s.pin != fp, sftp = false)
    }

    private val base: HttpUrl = s.host.trim().trimEnd('/').toHttpUrl()
    private val auth: String? = if (s.user.isBlank()) null else Credentials.basic(s.user, s.pass, Charsets.UTF_8)

    init {
        if (!base.isHttps) throw IOException("https required")
    }

    private fun url(path: String): HttpUrl {
        val b = base.newBuilder()
        for (seg in path.split('/')) if (seg.isNotEmpty()) b.addPathSegment(seg)
        return b.build()
    }

    private fun req(u: HttpUrl): Request.Builder = Request.Builder().url(u).also { r -> auth?.let { r.header("Authorization", it) } }

    override fun list(path: String): List<RemoteEntry> {
        val u = url(path).newBuilder().addPathSegment("").build() // složka končí lomítkem
        val r = req(u).header("Depth", "1")
            .method("PROPFIND", PROPFIND_BODY.toRequestBody("application/xml; charset=utf-8".toMediaType()))
            .build()
        guarded { http.newCall(r).execute() }.use { resp ->
            if (resp.code != 207 && !resp.isSuccessful) throw DavHttpException(resp.code)
            val body = resp.body?.byteStream() ?: return emptyList()
            val self = decode(u.encodedPath).trimEnd('/')
            return parse(body).filter { decode(it.first).trimEnd('/') != self }.map { (href, e) ->
                RemoteEntry(decode(href).trimEnd('/').substringAfterLast('/'), e.dir, e.size, e.mtime)
            }.filter { it.name.isNotEmpty() }
        }
    }

    private fun decode(href: String): String {
        val p = if (href.startsWith("http")) (href.toHttpUrlOrNull()?.encodedPath ?: href) else href
        return try {
            URLDecoder.decode(p.replace("+", "%2B"), "UTF-8")
        } catch (e: Exception) {
            p
        }
    }

    private fun String.toHttpUrlOrNull(): HttpUrl? = try {
        this.toHttpUrl()
    } catch (e: Exception) {
        null
    }

    private fun parse(input: java.io.InputStream): List<Pair<String, RemoteEntry>> {
        val out = ArrayList<Pair<String, RemoteEntry>>()
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
        p.setInput(input, null)
        var href = ""
        var dir = false
        var size = 0L
        var mtime = 0L
        var text = StringBuilder()
        val fmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
        while (true) {
            when (p.next()) {
                XmlPullParser.END_DOCUMENT -> return out
                XmlPullParser.START_TAG -> {
                    text = StringBuilder()
                    when (p.name) {
                        "response" -> {
                            href = ""; dir = false; size = 0L; mtime = 0L
                        }
                        "collection" -> { dir = true }
                    }
                }
                XmlPullParser.TEXT -> {
                    text.append(p.text)
                }
                XmlPullParser.END_TAG -> {
                    val v = text.toString().trim()
                    when (p.name) {
                        "href" -> { href = v }
                        "getcontentlength" -> { size = v.toLongOrNull() ?: 0L }
                        "getlastmodified" -> {
                            mtime = try {
                                fmt.parse(v)?.time ?: 0L
                            } catch (e: Exception) {
                                0L
                            }
                        }
                        "response" -> {
                            if (href.isNotEmpty()) out.add(href to RemoteEntry("", dir, size, mtime))
                        }
                    }
                }
            }
        }
    }

    override fun open(path: String): RemoteFile {
        val u = url(path)
        // velikost z odpovědi na první bajt (Content-Range: bytes 0-0/<velikost>)
        val total = guarded { http.newCall(req(u).header("Range", "bytes=0-0").build()).execute() }.use { resp ->
            if (!resp.isSuccessful) throw DavHttpException(resp.code)
            resp.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                ?: resp.header("Content-Length")?.toLongOrNull() ?: 0L
        }
        return object : RemoteFile {
            override val size = total
            override fun read(offset: Long, buf: ByteArray, off: Int, len: Int): Int {
                if (offset >= total) return -1
                val end = minOf(offset + len, total) - 1
                http.newCall(req(u).header("Range", "bytes=$offset-$end").build()).execute().use { resp ->
                    if (!resp.isSuccessful) throw DavHttpException(resp.code)
                    val inp = resp.body?.byteStream() ?: return -1
                    // server bez podpory Range pošle celý soubor od začátku – přeskočit na pozici
                    if (resp.code == 200 && offset > 0) {
                        var skip = offset
                        while (skip > 0) {
                            val n = inp.skip(skip)
                            if (n <= 0) return -1
                            skip -= n
                        }
                    }
                    var got = 0
                    val want = (end - offset + 1).toInt()
                    while (got < want) {
                        val n = inp.read(buf, off + got, want - got)
                        if (n < 0) break
                        got += n
                    }
                    return if (got == 0) -1 else got
                }
            }
            override fun close() {}
        }
    }

    override fun close() {}
}

// ---------------------------------------------------------------- SFTP

/** SFTP (SSH) – Raspberry Pi, linuxový server, NAS. Klíč serveru se ověřuje proti uloženému otisku. */
class SftpFs(private val s: NetServer) : RemoteFs {
    /** Otisk klíče serveru ve tvaru OpenSSH (SHA256:…). */
    private var seen: String? = null

    private val repo = object : HostKeyRepository {
        override fun check(host: String?, key: ByteArray?): Int {
            val fp = "SHA256:" + android.util.Base64.encodeToString(
                MessageDigest.getInstance("SHA-256").digest(key ?: ByteArray(0)),
                android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING,
            )
            seen = fp
            return when {
                s.pin.isEmpty() -> HostKeyRepository.NOT_INCLUDED
                s.pin == fp -> HostKeyRepository.OK
                else -> HostKeyRepository.CHANGED
            }
        }
        override fun add(hostkey: HostKey?, ui: UserInfo?) {}
        override fun remove(host: String?, type: String?) {}
        override fun remove(host: String?, type: String?, key: ByteArray?) {}
        override fun getKnownHostsRepositoryID(): String = "fif"
        override fun getHostKey(): Array<HostKey> = emptyArray()
        override fun getHostKey(host: String?, type: String?): Array<HostKey> = emptyArray()
    }

    private val session: com.jcraft.jsch.Session
    private val channel: ChannelSftp

    init {
        val host = s.host.substringBefore(':').trim()
        val port = s.host.substringAfter(':', "").toIntOrNull() ?: 22
        val jsch = JSch()
        jsch.hostKeyRepository = repo
        session = jsch.getSession(s.user, host, port)
        session.setPassword(s.pass)
        // neznámý / změněný klíč → konec ještě před odesláním hesla
        session.setConfig("StrictHostKeyChecking", "yes")
        session.setConfig("PreferredAuthentications", "password")
        try {
            session.connect(15000)
        } catch (e: JSchException) {
            val fp = seen
            if (fp != null && fp != s.pin) throw TrustNeeded(fp, changed = s.pin.isNotEmpty(), sftp = true)
            throw e
        }
        channel = try {
            (session.openChannel("sftp") as ChannelSftp).also { it.connect(15000) }
        } catch (e: Exception) {
            session.disconnect()
            throw e
        }
    }

    private fun p(path: String) = if (path.isEmpty()) "/" else path

    @Synchronized
    override fun list(path: String): List<RemoteEntry> =
        channel.ls(p(path)).mapNotNull { it as? ChannelSftp.LsEntry }
            .filter { it.filename != "." && it.filename != ".." }
            .map { RemoteEntry(it.filename, it.attrs.isDir, it.attrs.size, it.attrs.mTime * 1000L) }

    @Synchronized
    override fun open(path: String): RemoteFile {
        val total = channel.stat(p(path)).size
        return object : RemoteFile {
            override val size = total
            override fun read(offset: Long, buf: ByteArray, off: Int, len: Int): Int = synchronized(this@SftpFs) {
                if (offset >= total) return -1
                channel.get(p(path), null, offset).use { inp ->
                    var got = 0
                    while (got < len) {
                        val n = inp.read(buf, off + got, len - got)
                        if (n < 0) break
                        got += n
                    }
                    if (got == 0) -1 else got
                }
            }
            override fun close() {}
        }
    }

    override fun close() {
        try {
            channel.disconnect()
        } catch (e: Exception) {
        }
        try {
            session.disconnect()
        } catch (e: Exception) {
        }
    }
}
