package cz.fif.findinfiles

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.os.ProxyFileDescriptorCallback
import android.os.storage.StorageManager
import android.provider.OpenableColumns
import android.system.ErrnoException
import android.system.OsConstants
import java.io.FileNotFoundException

/**
 * Soubor z NASu předaný jiné aplikaci (přehrávač, prohlížeč PDF…). Nic se dopředu nestahuje:
 * aplikace čte jen ty části, které právě potřebuje (u filmu jde hned přetáčet).
 */
class NetProvider : ContentProvider() {
    companion object {
        fun authority(ctx: Context) = ctx.packageName + ".net"

        /** content://…net/<id úložiště>/<cesta>/<soubor> */
        fun uriFor(ctx: Context, docUri: String): Uri {
            val b = Uri.Builder().scheme("content").authority(authority(ctx)).appendPath(Net.serverId(docUri))
            for (seg in Net.path(docUri).split('/')) if (seg.isNotEmpty()) b.appendPath(seg)
            return b.build()
        }

        private fun docUri(uri: Uri): String {
            val segs = uri.pathSegments
            return Net.make(segs.firstOrNull() ?: "", segs.drop(1).joinToString("/"))
        }
    }

    override fun onCreate(): Boolean = true

    override fun getType(uri: Uri): String = Formats.mime(uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase() ?: "")

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, args: Array<out String>?, sort: String?): Cursor {
        val cols = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val c = MatrixCursor(cols)
        val name = uri.lastPathSegment ?: ""
        // velikost je v indexu – kvůli ní se není potřeba připojovat
        val size = try {
            val app = context?.applicationContext as? App
            app?.db?.readableDatabase?.rawQuery("SELECT size FROM docs WHERE uri = ?", arrayOf(docUri(uri)))?.use {
                if (it.moveToFirst()) it.getLong(0) else null
            }
        } catch (e: Exception) {
            null
        }
        c.addRow(cols.map { col ->
            when (col) {
                OpenableColumns.DISPLAY_NAME -> name
                OpenableColumns.SIZE -> size
                else -> null
            }
        }.toTypedArray())
        return c
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode.contains('w')) throw FileNotFoundException("read only")
        val ctx = context ?: throw FileNotFoundException()
        val d = docUri(uri)
        val server = NetStore.get(ctx, Net.serverId(d)) ?: throw FileNotFoundException("storage removed")
        val fs = try {
            Net.connect(server)
        } catch (e: Throwable) {
            throw FileNotFoundException(Net.errorText(ctx, e))
        }
        val file = try {
            fs.open(Net.path(d))
        } catch (e: Throwable) {
            fs.close()
            throw FileNotFoundException(Net.errorText(ctx, e))
        }
        val reader = BlockReader(file)
        // každý otevřený soubor má vlastní vlákno – pomalá síť u jednoho nebrzdí ostatní
        val thread = HandlerThread("fif-net").apply { start() }
        val sm = ctx.getSystemService(StorageManager::class.java)
        return sm.openProxyFileDescriptor(
            ParcelFileDescriptor.MODE_READ_ONLY,
            object : ProxyFileDescriptorCallback() {
                override fun onGetSize(): Long = file.size

                override fun onRead(offset: Long, size: Int, data: ByteArray): Int = try {
                    reader.read(offset, data, size)
                } catch (e: Throwable) {
                    throw ErrnoException("read", OsConstants.EIO)
                }

                override fun onRelease() {
                    try {
                        file.close()
                    } catch (e: Exception) {
                    }
                    try {
                        fs.close()
                    } catch (e: Exception) {
                    }
                    thread.quitSafely()
                }
            },
            Handler(thread.looper),
        )
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
