package cz.fif.findinfiles

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Environment
import android.os.SystemClock
import android.provider.DocumentsContract
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

data class IndexState(
    val running: Boolean = false,
    val message: String = "",
    val done: Int = 0,
    val total: Int = 0,
    val version: Int = 0,
    /** Krátká poznámka pro hlavní obrazovku: co se při poslední indexaci změnilo, nebo chyba. */
    val note: String = "",
)

/** Inkrementální indexace: znovu se zpracují jen nové a změněné soubory (podle velikosti a data změny). */
object Indexer {
    private class FileEntry(val uri: String, val name: String, val path: String, val ext: String, val size: Long, val mtime: Long)
    private class Existing(val id: Long, val size: Long, val mtime: Long)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(IndexState())
    val state: StateFlow<IndexState> = _state.asStateFlow()

    private val mutex = Mutex()
    private var job: Job? = null
    @Volatile private var again = false
    @Volatile private var lastNote = ""
    /** Složky, se kterými běží aktuální indexace. */
    @Volatile private var activeRoots: Set<String> = emptySet()

    /** Uživatel během indexace odebral složku – rozpracovaný běh se ukončí a spustí znovu. */
    private class FoldersChanged : Exception()

    private suspend fun checkpoint(app: App) {
        currentCoroutineContext().ensureActive()
        if (!app.prefs.folders.containsAll(activeRoots)) throw FoldersChanged()
    }

    private val PROJ = arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE,
        DocumentsContract.Document.COLUMN_LAST_MODIFIED,
    )

    /** Síťová úložiště se procházejí nejvýš jednou za čas (nebo hned po ručním obnovení). */
    private const val NET_INTERVAL = 30 * 60 * 1000L
    private val lastNetScan = HashMap<String, Long>()
    @Volatile private var fullNet = false

    /** Spuštění z aplikace (s průběhem v UI). full = projít i síťová úložiště hned. */
    @Synchronized
    fun start(ctx: Context, full: Boolean = false) {
        if (full) fullNet = true
        if (job?.isActive == true) {
            again = true // po doběhnutí proběhne ještě jednou (změnilo se nastavení)
            return
        }
        val app = ctx.applicationContext as App
        job = scope.launch {
            mutex.withLock {
                var msg: String
                do {
                    again = false
                    msg = runSafe(app)
                } while (again && isActive)
                finish(msg)
            }
        }
    }

    /** Spuštění z WorkManageru na pozadí. Když indexace už běží, nedělá nic. */
    suspend fun runInBackground(app: App) {
        if (!mutex.tryLock()) return
        try {
            var msg: String
            do {
                again = false
                msg = runSafe(app)
            } while (again && currentCoroutineContext().isActive)
            finish(msg)
        } finally {
            mutex.unlock()
        }
    }

    fun clearIndex(app: App) {
        scope.launch {
            job?.cancelAndJoin()
            mutex.withLock { Repo.clear(app) }
            finish(app.getString(R.string.idx_cleared))
        }
    }

    private fun finish(msg: String) {
        _state.value = IndexState(false, msg, version = _state.value.version + 1, note = lastNote)
        lastNote = ""
    }

    private fun progress(msg: String, done: Int, total: Int) {
        _state.value = IndexState(true, msg, done, total, _state.value.version)
    }

    private suspend fun runSafe(app: App): String = try {
        runOnce(app)
    } catch (e: FoldersChanged) {
        again = true // odebraná složka: začít znovu, záznamy z ní se smažou v dalším běhu
        ""
    } catch (e: CancellationException) {
        app.getString(R.string.idx_cancelled).also { lastNote = it }
    } catch (e: Throwable) {
        app.getString(R.string.idx_error, e.message ?: e.javaClass.simpleName).also { lastNote = it }
    }

    private suspend fun runOnce(app: App): String {
        val prefs = app.prefs
        val exts = prefs.exts
        val ocrOn = prefs.ocr
        // jednorázově: hudba, videa a fotky se zpracují znovu, aby se načetly jejich popisné údaje
        val mig = app.getSharedPreferences("prefs_migrate", android.content.Context.MODE_PRIVATE)
        if (!mig.getBoolean("metaTags", false)) {
            Repo.markMediaDirty(app)
            mig.edit().putBoolean("metaTags", true).apply()
        }
        val db = app.db.writableDatabase

        progress(app.getString(R.string.idx_scanning), 0, 0)
        lastNote = ""
        val found = ArrayList<FileEntry>()
        val failedRoots = ArrayList<String>()
        activeRoots = prefs.folders.toSet()
        // složka uvnitř jiné (úspěšně prošlé) přidané složky se neprochází podruhé – nadřazené jdou první
        val labels = activeRoots.associateWith { Paths.folderLabel(app, it) }
        // vyloučené podsložky i jako popisky – platí pak, i když se složka prochází jiným způsobem
        // (vyloučena přes systémový výběr, ale prochází se s nadřazenou složkou přes přístup ke všem souborům)
        val excl = HashSet(prefs.excluded)
        for (e in prefs.excluded) {
            when {
                e.startsWith("id:") -> excl.add("label:" + Paths.labelOfDocId(app, e.removePrefix("id:")))
                e.startsWith("path:") -> excl.add("label:" + Paths.labelOfFile(app, e.removePrefix("path:")))
            }
        }
        val doneLabels = ArrayList<String>()
        val forceNet = fullNet
        fullNet = false
        for (f in activeRoots.sortedBy { labels.getValue(it).length }) {
            checkpoint(app)
            val label = labels.getValue(f)
            if (doneLabels.any { Paths.contains(it, label) }) continue
            if (Net.isNet(f)) {
                // NAS: ne při každém návratu do aplikace – jen po ručním obnovení nebo jednou za čas
                val last = synchronized(lastNetScan) { lastNetScan[f] } ?: 0L
                if (!forceNet && System.currentTimeMillis() - last < NET_INTERVAL) {
                    failedRoots.add(f) // záznamy nechat, jak jsou
                    continue
                }
            }
            val ok = if (Net.isNet(f)) scanNet(app, f, prefs.exts, excl, prefs.ocr, found)
            else if (Paths.isFile(f)) scanFiles(app, f, prefs.exts, excl, prefs.ocr, found)
            else scan(app, app.contentResolver, Uri.parse(f), prefs.exts, excl, prefs.ocr, found)
            if (ok && Net.isNet(f)) synchronized(lastNetScan) { lastNetScan[f] = System.currentTimeMillis() }
            if (ok) doneLabels.add(label)
            else failedRoots.add(f) // složka teď není dostupná – její záznamy v indexu nemazat
        }

        val existing = HashMap<String, Existing>()
        db.rawQuery("SELECT id, uri, size, mtime FROM docs", null).use { c ->
            while (c.moveToNext()) existing[c.getString(1)] = Existing(c.getLong(0), c.getLong(2), c.getLong(3))
        }

        // soubory uvnitř archivu: "<uri archivu>!/…"
        fun childrenOf(zipUri: String): List<Long> {
            val prefix = zipUri + Zips.SEP
            return existing.entries.filter { it.key.startsWith(prefix) }.map { it.value.id }
        }

        val keep = HashSet<Long>()
        val todo = ArrayList<Pair<FileEntry, Long?>>()
        val seenUris = HashSet<String>()
        val seenFiles = HashSet<String>()
        for (f in found) {
            if (!seenUris.add(f.uri)) continue
            // stejný soubor přes dvě různé cesty (systémový výběr i přístup ke všem souborům)
            if (!seenFiles.add(f.path + "/" + f.name + "|" + f.size)) continue
            val e = existing[f.uri]
            val changed = e == null || e.size != f.size || e.mtime != f.mtime
            if (e != null) keep.add(e.id)
            if (!changed && Formats.key(f.ext) == "zip") keep.addAll(childrenOf(f.uri))
            if (changed) todo.add(f to e?.id)
        }

        // smazané soubory / odebrané nebo vyloučené složky / vypnuté formáty
        val removed = existing.entries
            .filter { en -> en.value.id !in keep && failedRoots.none { r -> en.key.startsWith(r) } }
            .map { it.value }
        if (removed.isNotEmpty()) {
            db.beginTransaction()
            try {
                for (e in removed) deleteDoc(app, db, e.id)
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        }

        // nejdřív nově přidané soubory (menší napřed, ať jsou rychle k dispozici), potom změněné
        todo.sortWith(compareBy<Pair<FileEntry, Long?>>({ it.second != null }, { it.first.size }))
        val started = SystemClock.elapsedRealtime()
        var done = 0
        db.beginTransaction()
        try {
            var batchStart = SystemClock.elapsedRealtime()
            for ((f, oldId) in todo) {
                checkpoint(app)
                progress(app.getString(R.string.idx_indexing, done + 1, todo.size, f.name) + eta(app, started, done, todo.size), done, todo.size)
                var text = ""
                var err: String? = null
                val isZip = Formats.key(f.ext) == "zip"
                val items = ArrayList<Extractors.ZipItem>()
                // filmy, hudba… (jen podle názvu): obsah se vůbec nečte
                val remote = Net.isNet(f.uri)
                val nameOnly = remote || Formats.mode(f.ext, exts, ocrOn) == Formats.Mode.NAME
                if (remote) {
                    // soubory na NASu jen podle názvu – nic se nestahuje
                } else try {
                    // u filmů, hudby a fotek jen popisné údaje (interpret, album, značky fotky…)
                    text = if (nameOnly) Meta.read(app, Uri.parse(f.uri), f.ext)
                    else if (isZip) Extractors.zip(app, Uri.parse(f.uri), exts, items)
                    else Extractors.extract(app, Uri.parse(f.uri), f.ext, f.size)
                    // fotka s OCR: k přečtenému textu i její popis a značky
                    if (!nameOnly && Formats.key(f.ext) == "img") {
                        val meta = Meta.read(app, Uri.parse(f.uri), f.ext)
                        if (meta.isNotEmpty()) text = meta + "\n" + text
                    }
                } catch (e: Throwable) {
                    err = e.message ?: e.javaClass.simpleName
                }
                if (oldId != null) deleteDoc(app, db, oldId)
                if (isZip) for (cid in childrenOf(f.uri)) deleteDoc(app, db, cid)
                insertDoc(app, db, f, text, err) // u ZIP: text = seznam souborů v archivu
                for (item in items) {
                    val name = item.path.substringAfterLast('/')
                    val dir = item.path.substringBeforeLast('/', "")
                    val child = FileEntry(
                        f.uri + Zips.SEP + item.path, name,
                        f.path + "/" + f.name + (if (dir.isEmpty()) "" else "/$dir"),
                        name.substringAfterLast('.', "").lowercase(), f.size, f.mtime,
                    )
                    insertDoc(app, db, child, item.text, item.error)
                }
                done++
                val now = SystemClock.elapsedRealtime()
                if (done % 30 == 0 || now - batchStart > 1500) {
                    // průběžné uložení – přerušená indexace nepřijde nazmar
                    db.setTransactionSuccessful()
                    db.endTransaction()
                    db.beginTransaction()
                    batchStart = now
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }

        val total = DatabaseUtils.queryNumEntries(db, "docs").toInt()
        app.prefs.lastIndexed = System.currentTimeMillis()
        val sb = StringBuilder(app.getString(R.string.idx_done, app.resources.getQuantityString(R.plurals.files, total, total)))
        val note = ArrayList<String>()
        if (done > 0) note.add(app.getString(R.string.idx_done_new, done).removePrefix(" · "))
        if (removed.isNotEmpty()) note.add(app.getString(R.string.idx_done_removed, removed.size).removePrefix(" · "))
        // nedostupný NAS (poznamenaný při procházení) zůstane v poznámce
        if (lastNote.isNotEmpty()) note.add(lastNote)
        for (n in note) sb.append(" · ").append(n)
        lastNote = note.joinToString(" · ")
        return sb.toString()
    }

    /** Odhad zbývajícího času podle dosavadní rychlosti. */
    private fun eta(app: App, started: Long, done: Int, total: Int): String {
        if (done < 5) return ""
        val perFile = (SystemClock.elapsedRealtime() - started).toDouble() / done
        val leftMin = (perFile * (total - done) / 60000.0).toInt()
        return " · " + if (leftMin < 1) app.getString(R.string.idx_eta_less) else app.getString(R.string.idx_eta_min, leftMin)
    }

    private suspend fun scan(
        app: App, cr: ContentResolver, tree: Uri, exts: Set<String>, excluded: Set<String>, ocr: Boolean,
        out: ArrayList<FileEntry>,
    ): Boolean {
        val rootId = try {
            DocumentsContract.getTreeDocumentId(tree)
        } catch (e: Exception) {
            return false
        }
        val rootLabel = Paths.label(app, tree)
        val stack = ArrayDeque<Pair<String, String>>()
        stack.addLast(rootId to "")
        while (stack.isNotEmpty()) {
            checkpoint(app)
            val (docId, rel) = stack.removeLast()
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val c = (try {
                cr.query(childrenUri, PROJ, null, null, null)
            } catch (e: Exception) {
                null
            })
            if (c == null) {
                if (docId == rootId) return false
                continue
            }
            try {
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    if (name.startsWith(".")) continue
                    val mime = c.getString(2)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        val sub = if (rel.isEmpty()) name else "$rel/$name"
                        if ("id:$id" in excluded || "name:${name.lowercase()}" in excluded || "label:$rootLabel/$sub" in excluded) continue
                        stack.addLast(id to sub)
                        continue
                    }
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if (Formats.mode(ext, exts, ocr) == Formats.Mode.SKIP) continue
                    val size = if (c.isNull(3)) 0L else c.getLong(3)
                    val mtime = if (c.isNull(4)) 0L else c.getLong(4)
                    val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id).toString()
                    val path = if (rel.isEmpty()) rootLabel else "$rootLabel/$rel"
                    out.add(FileEntry(uri, name, path, ext, size, mtime))
                    if (out.size % 250 == 0) progress(app.getString(R.string.idx_scanning_n, out.size), 0, 0)
                }
            } finally {
                c.close()
            }
        }
        return true
    }

    /** Procházení přes „přístup ke všem souborům“ (umí i celé úložiště a Download). */
    private suspend fun scanFiles(
        app: App, folder: String, exts: Set<String>, excluded: Set<String>, ocr: Boolean,
        out: ArrayList<FileEntry>,
    ): Boolean {
        val root = File(Paths.filePath(folder))
        if (root.listFiles() == null) return false
        val rootLabel = Paths.labelOfFile(app, root.absolutePath)
        val storageRoot = Environment.getExternalStorageDirectory().absolutePath
        val stack = ArrayDeque<Pair<File, String>>()
        stack.addLast(root to "")
        while (stack.isNotEmpty()) {
            checkpoint(app)
            val (dir, rel) = stack.removeLast()
            val children = dir.listFiles() ?: continue
            for (f in children) {
                val name = f.name
                if (name.startsWith(".")) continue
                if (f.isDirectory) {
                    if (name == "Android" && dir.absolutePath == storageRoot) continue // data aplikací
                    val sub = if (rel.isEmpty()) name else "$rel/$name"
                    if ("path:${f.absolutePath}" in excluded || "name:${name.lowercase()}" in excluded || "label:$rootLabel/$sub" in excluded) continue
                    stack.addLast(f to sub)
                    continue
                }
                val ext = name.substringAfterLast('.', "").lowercase()
                if (Formats.mode(ext, exts, ocr) == Formats.Mode.SKIP) continue
                val path = if (rel.isEmpty()) rootLabel else "$rootLabel/$rel"
                out.add(FileEntry(Uri.fromFile(f).toString(), name, path, ext, f.length(), f.lastModified()))
                if (out.size % 250 == 0) progress(app.getString(R.string.idx_scanning_n, out.size), 0, 0)
            }
        }
        return true
    }

    /** Síťové úložiště: jen seznam souborů (názvy, velikost, datum) – obsah se nestahuje. */
    private suspend fun scanNet(
        app: App, folder: String, exts: Set<String>, excluded: Set<String>, ocr: Boolean,
        out: ArrayList<FileEntry>,
    ): Boolean {
        val server = NetStore.get(app, Net.serverId(folder)) ?: return false
        val rootLabel = Net.label(app, folder)
        val fs = try {
            Net.connect(server)
        } catch (e: Throwable) {
            lastNote = app.getString(R.string.net_idx_unreachable, rootLabel)
            NetStore.setStatus(app, server.id, Net.errorText(app, e))
            return false
        }
        try {
            val stack = ArrayDeque<Pair<String, String>>()
            stack.addLast(Net.path(folder) to "")
            var first = true
            while (stack.isNotEmpty()) {
                checkpoint(app)
                val (dir, rel) = stack.removeLast()
                val children = try {
                    fs.list(dir)
                } catch (e: Throwable) {
                    if (first) {
                        // kořen nejde přečíst – záznamy v indexu nemazat
                        NetStore.setStatus(app, server.id, Net.errorText(app, e))
                        lastNote = app.getString(R.string.net_idx_unreachable, rootLabel)
                        return false
                    }
                    continue
                }
                first = false
                for (c in children) {
                    val name = c.name
                    if (Net.hidden(name)) continue
                    if (c.dir) {
                        val sub = if (rel.isEmpty()) name else "$rel/$name"
                        if ("name:${name.lowercase()}" in excluded || "label:$rootLabel/$sub" in excluded ||
                            Net.make(server.id, Net.join(dir, name)) in excluded
                        ) continue
                        stack.addLast(Net.join(dir, name) to sub)
                        continue
                    }
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if (Formats.mode(ext, exts, ocr) == Formats.Mode.SKIP) continue
                    val path = if (rel.isEmpty()) rootLabel else "$rootLabel/$rel"
                    out.add(FileEntry(Net.make(server.id, Net.join(dir, name)), name, path, ext, c.size, c.mtime))
                    if (out.size % 250 == 0) progress(app.getString(R.string.idx_scanning_n, out.size), 0, 0)
                }
            }
            NetStore.setStatus(app, server.id, null)
            return true
        } finally {
            fs.close()
        }
    }

    private fun deleteDoc(app: App, db: SQLiteDatabase, id: Long) {
        val args = arrayOf(id.toString())
        db.delete("docs", "id = ?", args)
        db.delete("fts", "docid = ?", args)
        Repo.textFile(app, id).delete()
    }

    private fun insertDoc(app: App, db: SQLiteDatabase, f: FileEntry, text: String, err: String?) {
        val cv = ContentValues().apply {
            put("uri", f.uri)
            put("name", f.name)
            put("path", f.path)
            put("ext", f.ext)
            put("size", f.size)
            put("mtime", f.mtime)
            put("chars", text.length.toLong())
            if (err != null) put("error", err) else putNull("error")
        }
        val id = db.insertOrThrow("docs", null, cv)
        val fv = ContentValues().apply {
            put("docid", id)
            put("name", TextFold.norm(f.name))
            put("body", TextFold.norm(text))
        }
        db.insertOrThrow("fts", null, fv)
        if (text.isNotEmpty()) {
            val file = Repo.textFile(app, id)
            file.parentFile?.mkdirs()
            file.writeText(text)
        }
    }
}
