package cz.fif.findinfiles

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Xml
import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.msfscc.FileAttributes
import com.hierynomus.mssmb2.SMB2CreateDisposition
import com.hierynomus.mssmb2.SMB2ShareAccess
import com.hierynomus.mssmb2.SMBApiException
import com.hierynomus.security.bc.BCSecurityProvider
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.SmbConfig
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.connection.Connection
import com.hierynomus.smbj.session.Session
import com.hierynomus.smbj.share.DiskShare
import okhttp3.Credentials
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.Closeable
import java.io.IOException
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.URLDecoder
import java.net.UnknownHostException
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.EnumSet
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.net.ssl.SSLException

/**
 * Síťové úložiště (NAS přes SMB, nebo WebDAV přes https).
 * smb: host = "192.168.1.10" (příp. ":port"), share = sdílená složka
 * dav: host = celá adresa "https://server:port/cesta"
 */
data class NetServer(
    val id: String,
    val type: String,
    val name: String,
    val host: String,
    val share: String,
    val user: String,
    val pass: String,
) {
    companion object {
        const val SMB = "smb"
        const val DAV = "dav"
        fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(10)
    }
}

class RemoteEntry(val name: String, val dir: Boolean, val size: Long, val mtime: Long)

interface RemoteFile : Closeable {
    val size: Long
    /** Přečte až [len] bajtů od pozice [offset]; -1 = konec souboru. */
    fun read(offset: Long, buf: ByteArray, off: Int, len: Int): Int
}

interface RemoteFs : Closeable {
    fun list(path: String): List<RemoteEntry>
    fun open(path: String): RemoteFile
}

/** Hesla jsou zašifrovaná klíčem v bezpečném úložišti telefonu (Android Keystore) – klíč z telefonu nejde vytáhnout. */
private object Secret {
    private const val ALIAS = "fif_net_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getEntry(ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    fun encrypt(s: String): String {
        if (s.isEmpty()) return ""
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(s.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
    }

    fun decrypt(s: String): String {
        if (s.isEmpty()) return ""
        return try {
            val iv = Base64.decode(s.substringBefore(':'), Base64.NO_WRAP)
            val ct = Base64.decode(s.substringAfter(':'), Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(c.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}

/** Uložená úložiště (bez hesel v čitelné podobě). */
object NetStore {
    @Volatile private var cache: List<NetServer>? = null

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("net", Context.MODE_PRIVATE)

    @Synchronized
    fun all(ctx: Context): List<NetServer> {
        cache?.let { return it }
        val list = ArrayList<NetServer>()
        try {
            val a = JSONArray(sp(ctx).getString("servers", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                list.add(
                    NetServer(
                        o.getString("id"), o.getString("type"), o.optString("name"), o.getString("host"),
                        o.optString("share"), o.optString("user"), Secret.decrypt(o.optString("pass")),
                    )
                )
            }
        } catch (e: Exception) {
        }
        cache = list
        return list
    }

    fun get(ctx: Context, id: String): NetServer? = all(ctx).firstOrNull { it.id == id }

    @Synchronized
    private fun write(ctx: Context, list: List<NetServer>) {
        val a = JSONArray()
        for (s in list) {
            a.put(
                JSONObject().put("id", s.id).put("type", s.type).put("name", s.name).put("host", s.host)
                    .put("share", s.share).put("user", s.user).put("pass", Secret.encrypt(s.pass))
            )
        }
        sp(ctx).edit().putString("servers", a.toString()).apply()
        cache = list
    }

    fun save(ctx: Context, s: NetServer) = write(ctx, all(ctx).filter { it.id != s.id } + s)

    fun remove(ctx: Context, id: String) = write(ctx, all(ctx).filter { it.id != id })
}

object Net {
    private const val PREFIX = "net:"

    /** Složka i soubor na síťovém úložišti: "net:<id úložiště>:/cesta". */
    fun isNet(s: String): Boolean = s.startsWith(PREFIX)

    fun make(id: String, path: String): String = "$PREFIX$id:" + "/" + path.trim('/')

    fun serverId(s: String): String = s.removePrefix(PREFIX).substringBefore(':')

    fun path(s: String): String = "/" + s.removePrefix(PREFIX).substringAfter(':', "").trim('/')

    fun join(path: String, name: String): String = if (path == "/" || path.isEmpty()) "/$name" else "$path/$name"

    fun label(ctx: Context, s: String): String {
        val srv = NetStore.get(ctx, serverId(s))
        val head = srv?.name?.ifBlank { null } ?: srv?.host ?: ctx.getString(R.string.net_unknown)
        val p = path(s).trim('/')
        return if (p.isEmpty()) head else "$head/$p"
    }

    fun connect(s: NetServer): RemoteFs = if (s.type == NetServer.SMB) SmbFs(s) else DavFs(s)

    /** Srozumitelná chybová hláška pro uživatele. */
    fun errorText(ctx: Context, e: Throwable): String {
        var t: Throwable? = e
        while (t != null) {
            when (t) {
                is UnknownHostException, is ConnectException, is NoRouteToHostException, is SocketTimeoutException ->
                    return ctx.getString(R.string.net_err_unreachable)
                is SSLException -> return ctx.getString(R.string.net_err_ssl)
                is SMBApiException -> {
                    val st = t.status?.name ?: ""
                    return when {
                        st.contains("LOGON_FAILURE") || st.contains("WRONG_PASSWORD") || st.contains("ACCOUNT") ->
                            ctx.getString(R.string.net_err_login)
                        st.contains("BAD_NETWORK_NAME") -> ctx.getString(R.string.net_err_share)
                        st.contains("ACCESS_DENIED") -> ctx.getString(R.string.net_err_denied)
                        st.contains("NOT_FOUND") -> ctx.getString(R.string.net_err_notfound)
                        else -> ctx.getString(R.string.net_err_other, st)
                    }
                }
                is DavHttpException -> return when (t.code) {
                    401 -> ctx.getString(R.string.net_err_login)
                    403 -> ctx.getString(R.string.net_err_denied)
                    404 -> ctx.getString(R.string.net_err_notfound)
                    405, 501 -> ctx.getString(R.string.net_err_nodav)
                    else -> ctx.getString(R.string.net_err_other, "HTTP ${t.code}")
                }
            }
            if (t.cause === t) break
            t = t.cause
        }
        return ctx.getString(R.string.net_err_other, e.message ?: e.javaClass.simpleName)
    }

    /** Složky NASu, které nejsou uživatelská data (koš, náhledy, snímky). */
    fun hidden(name: String): Boolean =
        name.startsWith(".") || name.startsWith("@") || name.startsWith("#") || name == "\$RECYCLE.BIN" ||
            name == "System Volume Information"
}

/** Čtení po větších blocích – přehrávače čtou po malých kouscích, po síti by to bylo pomalé. */
class BlockReader(private val f: RemoteFile, private val block: Int = 1 shl 20) {
    private val bufs = arrayOf(ByteArray(block), ByteArray(block))
    private val starts = longArrayOf(-1, -1)
    private val lens = intArrayOf(0, 0)
    private var next = 0

    private fun load(start: Long): Int {
        for (i in 0..1) if (starts[i] == start) return i
        val i = next
        next = 1 - next
        var got = 0
        val want = minOf(block.toLong(), f.size - start).toInt()
        while (got < want) {
            val n = f.read(start + got, bufs[i], got, want - got)
            if (n <= 0) break
            got += n
        }
        starts[i] = start
        lens[i] = got
        return i
    }

    @Synchronized
    fun read(offset: Long, out: ByteArray, len: Int): Int {
        if (offset >= f.size) return 0
        var done = 0
        while (done < len && offset + done < f.size) {
            val pos = offset + done
            val start = pos - pos % block
            val i = load(start)
            val inBlock = (pos - start).toInt()
            val avail = lens[i] - inBlock
            if (avail <= 0) break
            val n = minOf(avail, len - done)
            System.arraycopy(bufs[i], inBlock, out, done, n)
            done += n
        }
        return done
    }
}

/** NAS přes SMB 2/3 (Windows sdílení, QNAP, Synology…). */
class SmbFs(s: NetServer) : RemoteFs {
    companion object {
        private val client: SMBClient by lazy {
            SMBClient(
                SmbConfig.builder()
                    .withTimeout(30, TimeUnit.SECONDS)
                    .withSoTimeout(20, TimeUnit.SECONDS)
                    .withMultiProtocolNegotiate(true)
                    .withSecurityProvider(BCSecurityProvider())
                    .build()
            )
        }
    }

    private val conn: Connection
    private val session: Session
    private val share: DiskShare

    init {
        val host = s.host.substringBefore(':').trim()
        val port = s.host.substringAfter(':', "").toIntOrNull() ?: 445
        conn = client.connect(host, port)
        try {
            val auth = if (s.user.isBlank()) AuthenticationContext.guest() else {
                val domain = if (s.user.contains('\\')) s.user.substringBefore('\\') else ""
                val user = s.user.substringAfter('\\')
                AuthenticationContext(user, s.pass.toCharArray(), domain)
            }
            session = conn.authenticate(auth)
            share = session.connectShare(s.share.trim('/', '\\')) as? DiskShare
                ?: throw IOException("Not a disk share")
        } catch (e: Throwable) {
            try {
                conn.close()
            } catch (x: Exception) {
            }
            throw e
        }
    }

    private fun smb(p: String) = p.trim('/').replace('/', '\\')

    override fun list(path: String): List<RemoteEntry> =
        share.list(smb(path)).filter { it.fileName != "." && it.fileName != ".." }.map {
            RemoteEntry(
                it.fileName,
                (it.fileAttributes and FileAttributes.FILE_ATTRIBUTE_DIRECTORY.value) != 0L,
                it.endOfFile,
                it.lastWriteTime.toEpochMillis(),
            )
        }

    override fun open(path: String): RemoteFile {
        val f = share.openFile(
            smb(path), EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL,
            SMB2CreateDisposition.FILE_OPEN, null,
        )
        val total = f.fileInformation.standardInformation.endOfFile
        return object : RemoteFile {
            override val size = total
            override fun read(offset: Long, buf: ByteArray, off: Int, len: Int): Int = f.read(buf, offset, off, len)
            override fun close() = f.close()
        }
    }

    override fun close() {
        for (c in listOf<AutoCloseable>(share, session, conn)) try {
            c.close()
        } catch (e: Exception) {
        }
    }
}

class DavHttpException(val code: Int) : IOException("HTTP $code")

/** WebDAV přes https (QNAP, Synology, Nextcloud…). Heslo jde jen šifrovaným spojením. */
class DavFs(private val s: NetServer) : RemoteFs {
    companion object {
        private val http: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build()
        }
        private val PROPFIND_BODY = """<?xml version="1.0" encoding="utf-8"?>
<d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/><d:getcontentlength/><d:getlastmodified/></d:prop></d:propfind>"""
    }

    private val base: HttpUrl = s.host.trim().trimEnd('/').toHttpUrl()
    private val auth: String? = if (s.user.isBlank()) null else Credentials.basic(s.user, s.pass, Charsets.UTF_8)

    init {
        if (!base.isHttps) throw IOException("https required")
    }

    private fun url(path: String): HttpUrl {
        val b = base.newBuilder()
        for (seg in path.split('/')) if (seg.isNotEmpty()) b.addPathSegment(seg)
        return b.build()
    }

    private fun req(u: HttpUrl): Request.Builder = Request.Builder().url(u).also { r -> auth?.let { r.header("Authorization", it) } }

    override fun list(path: String): List<RemoteEntry> {
        val u = url(path).newBuilder().addPathSegment("").build() // složka končí lomítkem
        val r = req(u).header("Depth", "1")
            .method("PROPFIND", PROPFIND_BODY.toRequestBody("application/xml; charset=utf-8".toMediaType()))
            .build()
        http.newCall(r).execute().use { resp ->
            if (resp.code != 207 && !resp.isSuccessful) throw DavHttpException(resp.code)
            val body = resp.body?.byteStream() ?: return emptyList()
            val self = decode(u.encodedPath).trimEnd('/')
            return parse(body).filter { decode(it.first).trimEnd('/') != self }.map { (href, e) ->
                RemoteEntry(decode(href).trimEnd('/').substringAfterLast('/'), e.dir, e.size, e.mtime)
            }.filter { it.name.isNotEmpty() }
        }
    }

    private fun decode(href: String): String {
        val p = if (href.startsWith("http")) (href.toHttpUrlOrNull()?.encodedPath ?: href) else href
        return try {
            URLDecoder.decode(p.replace("+", "%2B"), "UTF-8")
        } catch (e: Exception) {
            p
        }
    }

    private fun String.toHttpUrlOrNull(): HttpUrl? = try {
        this.toHttpUrl()
    } catch (e: Exception) {
        null
    }

    private fun parse(input: java.io.InputStream): List<Pair<String, RemoteEntry>> {
        val out = ArrayList<Pair<String, RemoteEntry>>()
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
        p.setInput(input, null)
        var href = ""
        var dir = false
        var size = 0L
        var mtime = 0L
        var text = StringBuilder()
        val fmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
        while (true) {
            when (p.next()) {
                XmlPullParser.END_DOCUMENT -> return out
                XmlPullParser.START_TAG -> {
                    text = StringBuilder()
                    when (p.name) {
                        "response" -> {
                            href = ""; dir = false; size = 0L; mtime = 0L
                        }
                        "collection" -> { dir = true }
                    }
                }
                XmlPullParser.TEXT -> {
                    text.append(p.text)
                }
                XmlPullParser.END_TAG -> {
                    val v = text.toString().trim()
                    when (p.name) {
                        "href" -> { href = v }
                        "getcontentlength" -> { size = v.toLongOrNull() ?: 0L }
                        "getlastmodified" -> {
                            mtime = try {
                                fmt.parse(v)?.time ?: 0L
                            } catch (e: Exception) {
                                0L
                            }
                        }
                        "response" -> {
                            if (href.isNotEmpty()) out.add(href to RemoteEntry("", dir, size, mtime))
                        }
                    }
                }
            }
        }
    }

    override fun open(path: String): RemoteFile {
        val u = url(path)
        // velikost z odpovědi na první bajt (Content-Range: bytes 0-0/<velikost>)
        val total = http.newCall(req(u).header("Range", "bytes=0-0").build()).execute().use { resp ->
            if (!resp.isSuccessful) throw DavHttpException(resp.code)
            resp.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                ?: resp.header("Content-Length")?.toLongOrNull() ?: 0L
        }
        return object : RemoteFile {
            override val size = total
            override fun read(offset: Long, buf: ByteArray, off: Int, len: Int): Int {
                if (offset >= total) return -1
                val end = minOf(offset + len, total) - 1
                http.newCall(req(u).header("Range", "bytes=$offset-$end").build()).execute().use { resp ->
                    if (!resp.isSuccessful) throw DavHttpException(resp.code)
                    val inp = resp.body?.byteStream() ?: return -1
                    // server bez podpory Range pošle celý soubor od začátku – přeskočit na pozici
                    if (resp.code == 200 && offset > 0) {
                        var skip = offset
                        while (skip > 0) {
                            val n = inp.skip(skip)
                            if (n <= 0) return -1
                            skip -= n
                        }
                    }
                    var got = 0
                    val want = (end - offset + 1).toInt()
                    while (got < want) {
                        val n = inp.read(buf, off + got, want - got)
                        if (n < 0) break
                        got += n
                    }
                    return if (got == 0) -1 else got
                }
            }
            override fun close() {}
        }
    }

    override fun close() {}
}
