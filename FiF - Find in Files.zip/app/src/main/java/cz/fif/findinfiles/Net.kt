package cz.fif.findinfiles

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.hierynomus.mssmb2.SMBApiException
import com.jcraft.jsch.JSchException
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.IOException
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.KeyStore
import java.security.MessageDigest
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.net.ssl.SSLException

/**
 * Síťové úložiště.
 * smb: host = "192.168.1.10" (příp. ":port"); share = pevná sdílená složka (starší úložiště),
 *      prázdné = první část cesty je sdílená složka (nabízí se seznam)
 * dav: host = celá adresa "https://server:port/cesta"
 * sftp: host = "server" (příp. ":port")
 * pin = otisk certifikátu (dav) nebo klíče serveru (sftp), kterému uživatel důvěřuje
 */
data class NetServer(
    val id: String,
    val type: String,
    val name: String,
    val host: String,
    val share: String,
    val user: String,
    val pass: String,
    val pin: String = "",
) {
    companion object {
        const val SMB = "smb"
        const val DAV = "dav"
        const val SFTP = "sftp"
        fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(10)
    }

    /** Krátký popis adresy do seznamu úložišť. */
    val address: String
        get() = when (type) {
            DAV -> host.substringAfter("://").trimEnd('/')
            else -> host + if (share.isNotBlank()) "/" + share else ""
        }

    val displayName: String get() = name.ifBlank { address.substringBefore('/') }
}

class RemoteEntry(val name: String, val dir: Boolean, val size: Long, val mtime: Long)

interface RemoteFile : Closeable {
    val size: Long
    /** Přečte až [len] bajtů od pozice [offset]; -1 = konec souboru. */
    fun read(offset: Long, buf: ByteArray, off: Int, len: Int): Int
}

interface RemoteFs : Closeable {
    fun list(path: String): List<RemoteEntry>
    fun open(path: String): RemoteFile
}

/** Server se představil certifikátem / klíčem, který zatím neznáme (nebo se změnil). */
class TrustNeeded(val fingerprint: String, val changed: Boolean, val sftp: Boolean) : IOException("trust needed")

/** Seznam sdílených složek se nepodařilo získat – uživatel zadá název ručně. */
class SharesUnavailable(cause: Throwable?) : IOException("shares unavailable", cause)

/** Hesla jsou zašifrovaná klíčem v bezpečném úložišti telefonu (Android Keystore) – klíč z telefonu nejde vytáhnout. */
private object Secret {
    private const val ALIAS = "fif_net_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getEntry(ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    fun encrypt(s: String): String {
        if (s.isEmpty()) return ""
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(s.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
    }

    fun decrypt(s: String): String {
        if (s.isEmpty()) return ""
        return try {
            val iv = Base64.decode(s.substringBefore(':'), Base64.NO_WRAP)
            val ct = Base64.decode(s.substringAfter(':'), Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(c.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}

/** Uložená úložiště (heslo zašifrované) a jejich stav po posledním procházení. */
object NetStore {
    @Volatile private var cache: List<NetServer>? = null

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("net", Context.MODE_PRIVATE)

    @Synchronized
    fun all(ctx: Context): List<NetServer> {
        cache?.let { return it }
        val list = ArrayList<NetServer>()
        try {
            val a = JSONArray(sp(ctx).getString("servers", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                list.add(
                    NetServer(
                        o.getString("id"), o.getString("type"), o.optString("name"), o.getString("host"),
                        o.optString("share"), o.optString("user"), Secret.decrypt(o.optString("pass")),
                        o.optString("pin"),
                    )
                )
            }
        } catch (e: Exception) {
        }
        cache = list
        return list
    }

    fun get(ctx: Context, id: String): NetServer? = all(ctx).firstOrNull { it.id == id }

    @Synchronized
    private fun write(ctx: Context, list: List<NetServer>) {
        val a = JSONArray()
        for (s in list) {
            a.put(
                JSONObject().put("id", s.id).put("type", s.type).put("name", s.name).put("host", s.host)
                    .put("share", s.share).put("user", s.user).put("pass", Secret.encrypt(s.pass)).put("pin", s.pin)
            )
        }
        sp(ctx).edit().putString("servers", a.toString()).apply()
        cache = list
    }

    /** Uloží nové nebo upravené úložiště (pořadí v seznamu zůstane). */
    fun save(ctx: Context, s: NetServer) {
        val list = all(ctx)
        write(ctx, if (list.any { it.id == s.id }) list.map { if (it.id == s.id) s else it } else list + s)
    }

    fun remove(ctx: Context, id: String) {
        write(ctx, all(ctx).filter { it.id != id })
        sp(ctx).edit().remove("last_$id").remove("err_$id").apply()
    }

    /** Výsledek posledního procházení: čas úspěchu, nebo chyba. */
    fun setStatus(ctx: Context, id: String, error: String?) {
        val e = sp(ctx).edit()
        if (error == null) e.putLong("last_$id", System.currentTimeMillis()).remove("err_$id")
        else e.putString("err_$id", error)
        e.apply()
    }

    fun lastScan(ctx: Context, id: String): Long = sp(ctx).getLong("last_$id", 0L)
    fun lastError(ctx: Context, id: String): String? = sp(ctx).getString("err_$id", null)
}

object Net {
    private const val PREFIX = "net:"

    /** Složka i soubor na síťovém úložišti: "net:<id úložiště>:/cesta". */
    fun isNet(s: String): Boolean = s.startsWith(PREFIX)

    fun make(id: String, path: String): String = "$PREFIX$id:" + "/" + path.trim('/')

    fun serverId(s: String): String = s.removePrefix(PREFIX).substringBefore(':')

    fun path(s: String): String = "/" + s.removePrefix(PREFIX).substringAfter(':', "").trim('/')

    fun join(path: String, name: String): String = if (path == "/" || path.isEmpty()) "/$name" else "$path/$name"

    fun label(ctx: Context, s: String): String {
        val srv = NetStore.get(ctx, serverId(s))
        val head = srv?.displayName ?: ctx.getString(R.string.net_unknown)
        val p = path(s).trim('/')
        return if (p.isEmpty()) head else "$head/$p"
    }

    fun connect(s: NetServer): RemoteFs = when (s.type) {
        NetServer.SMB -> SmbFs(s)
        NetServer.SFTP -> SftpFs(s)
        else -> DavFs(s)
    }

    fun icon(type: String?): Int = when (type) {
        NetServer.DAV -> R.drawable.ic_globe
        NetServer.SFTP -> R.drawable.ic_src_term
        else -> R.drawable.ic_src_nas
    }

    fun typeName(ctx: Context, type: String): String = ctx.getString(
        when (type) {
            NetServer.SMB -> R.string.net_type_smb
            NetServer.SFTP -> R.string.net_type_sftp
            else -> R.string.net_type_dav
        }
    )

    /** Otisk SHA-256 ve tvaru AB:CD:… */
    fun sha256(data: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(data).joinToString(":") { "%02X".format(it) }

    /** Srozumitelná chybová hláška pro uživatele. */
    fun errorText(ctx: Context, e: Throwable): String {
        var t: Throwable? = e
        while (t != null) {
            when (t) {
                is TrustNeeded -> return ctx.getString(if (t.changed) R.string.net_err_changed else R.string.net_err_ssl)
                is SharesUnavailable -> return ctx.getString(R.string.net_err_share)
                is UnknownHostException, is ConnectException, is NoRouteToHostException, is SocketTimeoutException ->
                    return ctx.getString(R.string.net_err_unreachable)
                is SSLException -> return ctx.getString(R.string.net_err_ssl)
                is SMBApiException -> {
                    val st = t.status?.name ?: ""
                    return when {
                        st.contains("LOGON_FAILURE") || st.contains("WRONG_PASSWORD") || st.contains("ACCOUNT") ->
                            ctx.getString(R.string.net_err_login)
                        st.contains("BAD_NETWORK_NAME") -> ctx.getString(R.string.net_err_share)
                        st.contains("ACCESS_DENIED") -> ctx.getString(R.string.net_err_denied)
                        st.contains("NOT_FOUND") -> ctx.getString(R.string.net_err_notfound)
                        else -> ctx.getString(R.string.net_err_other, st)
                    }
                }
                is DavHttpException -> return when (t.code) {
                    401 -> ctx.getString(R.string.net_err_login)
                    403 -> ctx.getString(R.string.net_err_denied)
                    404 -> ctx.getString(R.string.net_err_notfound)
                    405, 501 -> ctx.getString(R.string.net_err_nodav)
                    else -> ctx.getString(R.string.net_err_other, "HTTP ${t.code}")
                }
                is JSchException -> {
                    val m = t.message ?: ""
                    return when {
                        m.contains("Auth fail", true) || m.contains("authentication", true) -> ctx.getString(R.string.net_err_login)
                        m.contains("timeout", true) || m.contains("connect", true) -> ctx.getString(R.string.net_err_unreachable)
                        else -> ctx.getString(R.string.net_err_other, m)
                    }
                }
            }
            if (t.cause === t) break
            t = t.cause
        }
        return ctx.getString(R.string.net_err_other, e.message ?: e.javaClass.simpleName)
    }

    /** Složky NASu, které nejsou uživatelská data (koš, náhledy, snímky). */
    fun hidden(name: String): Boolean =
        name.startsWith(".") || name.startsWith("@") || name.startsWith("#") || name == "\$RECYCLE.BIN" ||
            name == "System Volume Information"

    /** Vypadá adresa jako webová (WebDAV), a ne jako Samba? */
    fun looksLikeWeb(address: String, port: Int?): Boolean {
        val a = address.trim().lowercase()
        if (a.startsWith("http://") || a.startsWith("https://")) return true
        val p = port ?: a.substringAfterLast(':', "").toIntOrNull()
        return p != null && p != 445 && p != 139
    }
}

/** Čtení po větších blocích – přehrávače čtou po malých kouscích, po síti by to bylo pomalé. */
class BlockReader(private val f: RemoteFile, private val block: Int = 1 shl 20) {
    private val bufs = arrayOf(ByteArray(block), ByteArray(block))
    private val starts = longArrayOf(-1, -1)
    private val lens = intArrayOf(0, 0)
    private var next = 0

    private fun load(start: Long): Int {
        for (i in 0..1) if (starts[i] == start) return i
        val i = next
        next = 1 - next
        var got = 0
        val want = minOf(block.toLong(), f.size - start).toInt()
        while (got < want) {
            val n = f.read(start + got, bufs[i], got, want - got)
            if (n <= 0) break
            got += n
        }
        starts[i] = start
        lens[i] = got
        return i
    }

    @Synchronized
    fun read(offset: Long, out: ByteArray, len: Int): Int {
        if (offset >= f.size) return 0
        var done = 0
        while (done < len && offset + done < f.size) {
            val pos = offset + done
            val start = pos - pos % block
            val i = load(start)
            val inBlock = (pos - start).toInt()
            val avail = lens[i] - inBlock
            if (avail <= 0) break
            val n = minOf(avail, len - done)
            System.arraycopy(bufs[i], inBlock, out, done, n)
            done += n
        }
        return done
    }
}
