package cz.fif.findinfiles

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.roundToInt

/**
 * Posuvník pro palec u pravého okraje. Je skrytý; při posouvání textu vyjede z boku jen fialový
 * obdélník a po chvíli bez pohybu zase zajede – text tak může jít až ke kraji.
 * Při tažení ukáže bublinu s číslem řádku / stránky.
 */
class ThumbScroller(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {
    private val dp = resources.displayMetrics.density
    private val thumbW = 10 * dp
    private val thumbH = 56 * dp
    private val margin = 3 * dp
    private val touchW = 36 * dp
    private var recycler: RecyclerView? = null
    private var fraction = 0f
    private var dragging = false
    private var longEnough = false
    /** 0 = schovaný za okrajem, 1 = vysunutý. */
    private var slide = 0f
    private var anim: ValueAnimator? = null
    private val hideRunnable = Runnable { animateTo(0f) }

    /** Popisek do bubliny podle polohy v textu (0 = začátek, 1 = konec). */
    var labelFor: ((Float) -> String)? = null

    /**
     * Odhad výšky položek (např. počet zalomených řádků podle délky textu). Bez něj se poloha počítá
     * z průměrné výšky viditelných položek – u odstavců různé délky pak posuvník skáče a zrychluje.
     */
    private var prefix: DoubleArray? = null
    /** Kolik pixelů odpovídá jedné jednotce odhadu – průběžně se dolaďuje podle skutečně vykreslených položek. */
    private var pxPerUnit = 0.0

    fun setWeights(w: FloatArray?) {
        if (w == null) {
            prefix = null
        } else {
            val p = DoubleArray(w.size + 1)
            for (i in w.indices) p[i + 1] = p[i] + w[i].coerceAtLeast(0.01f)
            prefix = p
        }
        pxPerUnit = 0.0
        update()
    }

    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6A1B9A.toInt() }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6A1B9A.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15 * dp
        isFakeBoldText = true
    }
    private val rect = RectF()
    private val bounds = Rect()

    fun attach(rv: RecyclerView) {
        recycler = rv
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                update()
                if (dy != 0 && longEnough) reveal()
            }
        })
    }

    /** Poloha podle odhadu výšek: (px nad obrazovkou, px pod obrazovkou), nebo null. */
    private fun weighted(rv: RecyclerView): Pair<Double, Double>? {
        val p = prefix ?: return null
        val n = p.size - 1
        if (n <= 0 || rv.childCount == 0 || rv.adapter?.itemCount != n) return null
        val lm = rv.layoutManager ?: return null
        var firstPos = Int.MAX_VALUE
        var lastPos = -1
        var firstTop = 0
        var lastBottom = 0
        var sumH = 0.0
        var sumW = 0.0
        for (i in 0 until rv.childCount) {
            val c = rv.getChildAt(i)
            val pos = rv.getChildAdapterPosition(c)
            if (pos < 0 || pos >= n) continue
            val top = lm.getDecoratedTop(c)
            val bottom = lm.getDecoratedBottom(c)
            if (pos < firstPos) { firstPos = pos; firstTop = top }
            if (pos > lastPos) { lastPos = pos; lastBottom = bottom }
            sumH += bottom - top
            sumW += p[pos + 1] - p[pos]
        }
        if (lastPos < 0 || sumW <= 0.0) return null
        val k = sumH / sumW
        // dolaďovat pomalu, aby posuvník necukal, když přijde jinak dlouhý odstavec
        pxPerUnit = if (pxPerUnit <= 0.0) k else pxPerUnit * 0.92 + k * 0.08
        val above = (p[firstPos] * pxPerUnit + (rv.paddingTop - firstTop)).coerceAtLeast(0.0)
        val below = ((p[n] - p[lastPos + 1]) * pxPerUnit + (lastBottom - rv.height + rv.paddingBottom)).coerceAtLeast(0.0)
        return Pair(if (rv.canScrollVertically(-1)) above else 0.0, if (rv.canScrollVertically(1)) below else 0.0)
    }

    fun update() {
        val rv = recycler ?: return
        val w = weighted(rv)
        if (w != null) {
            val (above, below) = w
            longEnough = above + below > rv.height
            if (!dragging) fraction = if (above + below > 0) (above / (above + below)).toFloat() else 0f
            invalidate()
            return
        }
        val range = rv.computeVerticalScrollRange()
        val extent = rv.computeVerticalScrollExtent()
        val offset = rv.computeVerticalScrollOffset()
        longEnough = range > extent * 2
        if (!dragging) fraction = if (range - extent > 0) offset.toFloat() / (range - extent) else 0f
        invalidate()
    }

    private fun reveal() {
        removeCallbacks(hideRunnable)
        if (slide < 1f && anim?.isRunning != true) animateTo(1f)
        if (!dragging) postDelayed(hideRunnable, 1500)
    }

    private fun animateTo(target: Float) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(slide, target).apply {
            duration = 180
            addUpdateListener {
                slide = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (slide <= 0f) return
        val right = width - margin + (1f - slide) * (thumbW + margin)
        val top = fraction.coerceIn(0f, 1f) * (height - thumbH)
        rect.set(right - thumbW, top, right, top + thumbH)
        canvas.drawRoundRect(rect, 3 * dp, 3 * dp, thumbPaint)
        if (dragging) {
            val rv = recycler ?: return
            val n = rv.adapter?.itemCount ?: 0
            if (n == 0) return
            val label = labelFor?.invoke(fraction.coerceIn(0f, 1f)) ?: return
            textPaint.getTextBounds(label, 0, label.length, bounds)
            val pad = 10 * dp
            val bw = bounds.width() + 2 * pad
            val bh = bounds.height() + 2 * pad
            val bx = right - thumbW - 12 * dp - bw
            val by = (top + thumbH / 2 - bh / 2).coerceIn(0f, height - bh)
            rect.set(bx, by, bx + bw, by + bh)
            canvas.drawRoundRect(rect, bh / 2, bh / 2, bubblePaint)
            canvas.drawText(label, bx + pad, by + pad + bounds.height(), textPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val rv = recycler ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // chytit jde jen vysunutý posuvník přímo prstem na něm a jen když text zrovna nejede setrvačností –
                // jinak by rychlé opakované švihání u pravého okraje omylem chytlo posuvník a skočilo na konec
                if (slide < 0.9f || event.x < width - touchW) return false
                if (rv.scrollState != RecyclerView.SCROLL_STATE_IDLE) return false
                val top = fraction.coerceIn(0f, 1f) * (height - thumbH)
                if (event.y < top - 12 * dp || event.y > top + thumbH + 12 * dp) return false
                dragging = true
                removeCallbacks(hideRunnable)
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                moveTo(rv, event.y)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) return false
                dragging = false
                update()
                reveal()
                return true
            }
        }
        return false
    }

    private fun moveTo(rv: RecyclerView, y: Float) {
        fraction = ((y - thumbH / 2) / (height - thumbH)).coerceIn(0f, 1f)
        val n = rv.adapter?.itemCount ?: return
        if (n == 0) return
        val p = prefix
        if (p != null && p.size == n + 1 && pxPerUnit > 0.0) {
            // cíl v odhadnutých pixelech → položka a posun uvnitř ní
            val total = p[n] * pxPerUnit + rv.paddingBottom - rv.height
            val target = (fraction * total.coerceAtLeast(0.0)) / pxPerUnit
            var lo = 0
            var hi = n - 1
            while (lo < hi) {
                val mid = (lo + hi + 1) / 2
                if (p[mid] <= target) lo = mid else hi = mid - 1
            }
            val inside = ((target - p[lo]) * pxPerUnit).roundToInt()
            (rv.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(lo, -inside)
            invalidate()
            return
        }
        if (n == 1) {
            // celý text v jednom poli: posunout přímo o pixely
            val target = (fraction * (rv.computeVerticalScrollRange() - rv.computeVerticalScrollExtent())).roundToInt()
            rv.scrollBy(0, target - rv.computeVerticalScrollOffset())
        } else {
            val pos = (fraction * (n - 1)).roundToInt()
            (rv.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(pos, 0)
        }
        invalidate()
    }
}

/** LayoutManager, který neposouvá seznam, když se klepne do textu (to dělalo „odskakování“). */
class NoJumpLayoutManager(ctx: Context) : LinearLayoutManager(ctx) {
    /**
     * Připravit (vykreslit mimo obrazovku) i jednu obrazovku textu nad a pod viditelnou částí.
     * Další výskyt pak bývá už nachystaný a přeskok na něj je plynulý i při rychlém klepání.
     */
    override fun calculateExtraLayoutSpace(state: RecyclerView.State, extraLayoutSpace: IntArray) {
        // jen když se text záměrně připravuje dopředu (krátké soubory) – jinak by se při každém
        // skoku sestavovaly tři obrazovky řádků a rychlé klepání by se zahltilo
        if (extraPx <= 0) {
            super.calculateExtraLayoutSpace(state, extraLayoutSpace)
            return
        }
        extraLayoutSpace[0] = extraPx
        extraLayoutSpace[1] = extraPx
    }

    /** Kolik pixelů textu mít nachystaných nad a pod obrazovkou (u kratších souborů postupně celý text). */
    var extraPx = 0

    override fun requestChildRectangleOnScreen(
        parent: RecyclerView, child: View, rect: Rect, immediate: Boolean, focusedChildVisible: Boolean,
    ): Boolean = false
}
