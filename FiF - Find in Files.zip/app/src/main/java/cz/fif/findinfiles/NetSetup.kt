package cz.fif.findinfiles

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import java.net.Inet4Address

/**
 * Síťová úložiště: přidání (nalezená v síti / podle typu), přihlášení, důvěra v certifikát,
 * výběr složek, úprava připojení. [onFolder] = přidat složku "net:<id>:/cesta", [onChanged] = překreslit.
 */
class NetSetup(
    private val act: AppCompatActivity,
    private val onFolder: (String) -> Unit,
    private val onChanged: () -> Unit,
) {
    private val dp = act.resources.displayMetrics.density
    private fun px(v: Int) = (v * dp).toInt()

    /** Typ ve formuláři (Nextcloud se ukládá jako WebDAV, jen se jinak vyplňuje). */
    private enum class Kind { SMB, DAV, NEXTCLOUD, SFTP }

    // ---------------------------------------------------------------- 1. výběr

    fun add() {
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val found = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val searching = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(22), px(6), px(22), px(6))
            addView(ProgressBar(act).apply { isIndeterminate = true }, LinearLayout.LayoutParams(px(16), px(16)))
            addView(TextView(act).apply {
                setText(R.string.net_searching)
                alpha = 0.65f
                textSize = 13f
                setPadding(px(10), 0, 0, 0)
            })
        }
        box.addView(section(R.string.net_found_lan))
        box.addView(found)
        box.addView(searching)
        box.addView(section(R.string.net_or_type))
        lateinit var dialog: AlertDialog
        fun choose(k: Kind) {
            dialog.dismiss()
            form(k, null)
        }
        box.addView(typeRow(R.drawable.ic_src_nas, R.string.net_type_smb, R.string.net_type_smb_note) { choose(Kind.SMB) })
        box.addView(typeRow(R.drawable.ic_globe, R.string.net_type_dav, R.string.net_type_dav_note) { choose(Kind.DAV) })
        box.addView(typeRow(R.drawable.ic_src_cloud, R.string.net_type_nc, R.string.net_type_nc_note) { choose(Kind.NEXTCLOUD) })
        box.addView(typeRow(R.drawable.ic_src_term, R.string.net_type_sftp, R.string.net_type_sftp_note) { choose(Kind.SFTP) })

        val discovery = Discovery(act) { name, host, port, smb ->
            val sub = host + (if (port != (if (smb) 445 else 22)) ":$port" else "") + " · " +
                act.getString(if (smb) R.string.net_type_smb else R.string.net_type_sftp)
            found.addView(typeRow(if (smb) R.drawable.ic_src_nas else R.drawable.ic_src_term, name, sub, connect = true) {
                dialog.dismiss()
                val h = if (port == (if (smb) 445 else 22)) host else "$host:$port"
                form(if (smb) Kind.SMB else Kind.SFTP, NetServer("", if (smb) NetServer.SMB else NetServer.SFTP, name, h, "", "", ""))
            })
        }
        dialog = MaterialAlertDialogBuilder(act)
            .setTitle(R.string.net_add_title)
            .setView(ScrollView(act).apply { addView(box) })
            .setNegativeButton(R.string.cancel, null)
            .create()
        dialog.setOnDismissListener { discovery.stop() }
        dialog.show()
        discovery.start()
        // po chvíli přestat ukazovat „hledám“
        Handler(Looper.getMainLooper()).postDelayed({
            searching.visibility = View.GONE
            if (found.childCount == 0) found.addView(TextView(act).apply {
                setText(R.string.net_found_none)
                alpha = 0.6f
                textSize = 13f
                setPadding(px(22), px(4), px(22), px(4))
            })
        }, 6000)
    }

    private fun section(res: Int) = TextView(act).apply {
        setText(res)
        textSize = 13f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(colorPrimary())
        setPadding(px(22), px(14), px(22), px(4))
    }

    private fun colorPrimary(): Int {
        val tv = android.util.TypedValue()
        act.theme.resolveAttribute(androidx.appcompat.R.attr.colorPrimary, tv, true)
        return tv.data
    }

    private fun typeRow(icon: Int, title: Int, sub: Int, onClick: () -> Unit) =
        typeRow(icon, act.getString(title), act.getString(sub), false, onClick)

    private fun typeRow(icon: Int, title: String, sub: String, connect: Boolean, onClick: () -> Unit): View {
        val row = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(22), px(10), px(22), px(10))
            val tv = android.util.TypedValue()
            act.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            setBackgroundResource(tv.resourceId)
            setOnClickListener { onClick() }
        }
        row.addView(ImageView(act).apply {
            setImageResource(icon)
            imageTintList = android.content.res.ColorStateList.valueOf(textColor())
            alpha = 0.8f
        }, LinearLayout.LayoutParams(px(24), px(24)))
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), 0, px(8), 0)
        }
        col.addView(TextView(act).apply { text = title; textSize = 16f })
        col.addView(TextView(act).apply { text = sub; textSize = 12.5f; alpha = 0.65f })
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (connect) row.addView(TextView(act).apply {
            setText(R.string.net_connect_short)
            setTextColor(colorPrimary())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            textSize = 13f
        })
        return row
    }

    private fun textColor(): Int {
        val tv = android.util.TypedValue()
        act.theme.resolveAttribute(android.R.attr.textColorPrimary, tv, true)
        return if (tv.resourceId != 0) act.getColor(tv.resourceId) else tv.data
    }

    // ---------------------------------------------------------------- 2. přihlášení

    /** Pole s plovoucím popiskem; u hesla tečky a oko pro zobrazení. */
    private fun field(hint: Int, type: Int = InputType.TYPE_CLASS_TEXT, password: Boolean = false): Pair<TextInputLayout, TextInputEditText> {
        val til = TextInputLayout(act)
        til.hint = act.getString(hint)
        val et = TextInputEditText(til.context)
        et.setSingleLine() // před inputType – jinak by u hesla zrušilo tečky
        et.inputType = type
        til.addView(et, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        if (password) til.endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
        til.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = px(8) }
        return til to et
    }

    /** Úprava připojení uloženého úložiště (složky zůstanou). */
    fun edit(s: NetServer) {
        form(
            when {
                s.type == NetServer.SMB -> Kind.SMB
                s.type == NetServer.SFTP -> Kind.SFTP
                else -> Kind.DAV
            },
            s, edit = true,
        )
    }

    private fun form(kind: Kind, prev: NetServer?, error: String? = null, edit: Boolean = false) {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(22), px(4), px(22), 0)
        }
        val note = TextView(act).apply {
            textSize = 12.5f
            alpha = 0.7f
            setText(
                when (kind) {
                    Kind.SMB -> R.string.net_type_smb_note
                    Kind.DAV -> R.string.net_type_dav_note
                    Kind.NEXTCLOUD -> R.string.net_type_nc_note
                    Kind.SFTP -> R.string.net_type_sftp_note
                }
            )
        }
        val (nameL, name) = field(R.string.net_name_hint)
        val (hostL, host) = field(
            when (kind) {
                Kind.SMB -> R.string.net_host_smb_hint
                Kind.SFTP -> R.string.net_host_sftp_hint
                Kind.NEXTCLOUD -> R.string.net_host_nc_hint
                Kind.DAV -> R.string.net_host_dav_hint
            },
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI,
        )
        val (userL, user) = field(R.string.net_user_hint)
        val (passL, pass) = field(R.string.net_pass_hint, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD, password = true)
        // pokročilé: port (a u starších Samba úložišť pevná sdílená složka)
        val (portL, port) = field(R.string.net_port_hint, InputType.TYPE_CLASS_NUMBER)
        portL.helperText = act.getString(R.string.net_port_help)
        portL.placeholderText = when (kind) {
            Kind.SMB -> "445"
            Kind.SFTP -> "22"
            else -> "443"
        }
        val (shareL, share) = field(R.string.net_share_hint)
        shareL.helperText = act.getString(R.string.net_share_help)
        val adv = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(portL)
            if (kind == Kind.SMB) addView(shareL)
        }
        val advToggle = TextView(act).apply {
            setText(R.string.net_advanced)
            setTextColor(colorPrimary())
            textSize = 13.5f
            setPadding(0, px(12), 0, px(4))
            setOnClickListener {
                adv.visibility = if (adv.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }
        // hlídání: adresa pro WebDAV zadaná u Samby
        val hint = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(px(12), px(10), px(12), px(10))
            setBackgroundResource(R.drawable.card_bg)
        }
        val hintText = TextView(act).apply { textSize = 13f }
        hint.addView(hintText)
        val err = TextView(act).apply {
            setTextColor(act.getColor(R.color.danger))
            text = error ?: ""
            visibility = if (error == null) View.GONE else View.VISIBLE
            setPadding(0, px(10), 0, 0)
        }
        box.addView(note)
        for (v in listOf(nameL, hostL)) box.addView(v)
        if (kind == Kind.SMB) box.addView(hint, LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(8) })
        for (v in listOf(userL, passL, advToggle, adv, err)) box.addView(v)

        // předvyplnění
        if (prev != null) {
            name.setText(prev.name)
            when (kind) {
                Kind.SMB, Kind.SFTP -> {
                    host.setText(prev.host.substringBefore(':'))
                    port.setText(prev.host.substringAfter(':', ""))
                }
                else -> {
                    val u = try {
                        prev.host.toHttpUrl()
                    } catch (e: Exception) {
                        null
                    }
                    if (u != null && u.port != 443) {
                        host.setText(prev.host.replaceFirst(":" + u.port, ""))
                        port.setText(u.port.toString())
                    } else host.setText(prev.host)
                }
            }
            share.setText(prev.share)
            user.setText(prev.user)
            pass.setText(prev.pass)
            if (port.text?.isNotEmpty() == true || prev.share.isNotEmpty()) adv.visibility = View.VISIBLE
        }

        lateinit var dialog: AlertDialog
        if (kind == Kind.SMB) {
            val check = object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val web = Net.looksLikeWeb(host.text.toString(), port.text.toString().toIntOrNull())
                    hint.visibility = if (web) View.VISIBLE else View.GONE
                    if (web) hintText.text = act.getString(R.string.net_hint_web)
                }
            }
            host.addTextChangedListener(check)
            port.addTextChangedListener(check)
            hint.addView(MaterialButton(act, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                setText(R.string.net_switch_dav)
                setOnClickListener {
                    dialog.dismiss()
                    var h = host.text.toString().trim()
                    if (!h.contains("://")) h = "https://$h"
                    form(Kind.DAV, NetServer(prev?.id ?: "", NetServer.DAV, name.text.toString(), h, "",
                        user.text.toString(), pass.text.toString()).let {
                        val p = port.text.toString().trim()
                        if (p.isNotEmpty() && !h.substringAfter("://").contains(':')) it.copy(host = "$h:$p") else it
                    })
                }
            })
            check.afterTextChanged(null)
        }

        dialog = MaterialAlertDialogBuilder(act)
            .setTitle(
                if (edit) act.getString(R.string.net_edit_title)
                else act.getString(
                    when (kind) {
                        Kind.SMB -> R.string.net_type_smb
                        Kind.DAV -> R.string.net_type_dav
                        Kind.NEXTCLOUD -> R.string.net_type_nc
                        Kind.SFTP -> R.string.net_type_sftp
                    }
                )
            )
            .setView(ScrollView(act).apply { addView(box) })
            .setPositiveButton(if (edit) R.string.save else R.string.net_connect, null)
            .setNegativeButton(R.string.cancel, null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val p = port.text.toString().trim().toIntOrNull()?.takeIf { it in 1..65535 }
                var h = host.text.toString().trim()
                var problem: String? = when {
                    h.isEmpty() -> act.getString(R.string.net_err_host)
                    port.text?.isNotBlank() == true && p == null -> act.getString(R.string.net_err_port)
                    kind == Kind.SFTP && user.text.isNullOrBlank() -> act.getString(R.string.net_err_user)
                    else -> null
                }
                val type: String
                when (kind) {
                    Kind.SMB, Kind.SFTP -> {
                        h = h.removePrefix("smb://").removePrefix("sftp://").removePrefix("\\\\").trim('/', '\\')
                        if (p != null) h = h.substringBefore(':') + ":" + p
                        type = if (kind == Kind.SMB) NetServer.SMB else NetServer.SFTP
                    }
                    Kind.DAV, Kind.NEXTCLOUD -> {
                        type = NetServer.DAV
                        if (!h.contains("://")) h = "https://$h"
                        if (!h.startsWith("https://", ignoreCase = true)) problem = problem ?: act.getString(R.string.net_err_https)
                        try {
                            var u = h.toHttpUrl()
                            if (p != null) u = u.newBuilder().port(p).build()
                            // Nextcloud: soubory uživatele leží na /remote.php/dav/files/<uživatel>/
                            if (kind == Kind.NEXTCLOUD && !u.encodedPath.contains("remote.php")) {
                                u = u.newBuilder().addPathSegments("remote.php/dav/files")
                                    .addPathSegment(user.text.toString().trim()).build()
                            }
                            h = u.toString().trimEnd('/')
                        } catch (e: Exception) {
                            problem = problem ?: act.getString(R.string.net_err_host)
                        }
                    }
                }
                if (problem != null) {
                    err.text = problem
                    err.visibility = View.VISIBLE
                    return@setOnClickListener
                }
                val s = NetServer(
                    prev?.id?.ifEmpty { null } ?: NetServer.newId(),
                    type,
                    name.text.toString().trim().ifEmpty { if (kind == Kind.NEXTCLOUD) "Nextcloud" else "" },
                    h,
                    if (kind == Kind.SMB) share.text.toString().trim().trim('/', '\\') else "",
                    user.text.toString().trim(),
                    pass.text.toString(),
                    // stejný server → důvěra v certifikát zůstává
                    if (prev != null && prev.host == h && prev.type == type) prev.pin else "",
                )
                dialog.dismiss()
                connect(s, edit) { fs -> if (edit) saved(s, fs) else browse(s, fs, first = true) }
            }
        }
        dialog.show()
    }

    private fun saved(s: NetServer, fs: RemoteFs) {
        act.lifecycleScope.launch(Dispatchers.IO) { fs.close() }
        NetStore.save(act, s)
        Toast.makeText(act, R.string.net_saved, Toast.LENGTH_SHORT).show()
        onChanged()
        Indexer.start(act, full = true)
    }

    // ---------------------------------------------------------------- připojení, důvěra

    /** Připojí se, ověří čtení kořene a předá otevřené připojení dál. */
    private fun connect(s: NetServer, edit: Boolean, then: (RemoteFs) -> Unit) {
        val progress = MaterialAlertDialogBuilder(act)
            .setMessage(R.string.net_connecting)
            .setCancelable(false)
            .show()
        act.lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) {
                var fs: RemoteFs? = null
                try {
                    val f = Net.connect(s)
                    fs = f
                    f.list("/")
                    Result.success(f)
                } catch (e: Throwable) {
                    try {
                        fs?.close()
                    } catch (x: Exception) {
                    }
                    Result.failure<RemoteFs>(e)
                }
            }
            progress.dismiss()
            res.onSuccess(then)
            res.onFailure { e ->
                when (e) {
                    is TrustNeeded -> askTrust(s, e) { connect(s.copy(pin = e.fingerprint), edit, then) }
                    is SharesUnavailable -> askShare { name -> connect(s.copy(share = name), edit, then) }
                    else -> form(kindOf(s), s, Net.errorText(act, e), edit)
                }
            }
        }
    }

    private fun kindOf(s: NetServer) = when (s.type) {
        NetServer.SMB -> Kind.SMB
        NetServer.SFTP -> Kind.SFTP
        else -> Kind.DAV
    }

    private fun askTrust(s: NetServer, t: TrustNeeded, onTrust: () -> Unit) {
        val msg = act.getString(
            when {
                t.changed -> R.string.net_trust_changed
                t.sftp -> R.string.net_trust_key
                else -> R.string.net_trust_cert
            },
            s.address,
        ) + "\n\n" + act.getString(R.string.net_trust_fp) + "\n" + t.fingerprint + "\n\n" + act.getString(R.string.net_trust_note)
        MaterialAlertDialogBuilder(act)
            .setTitle(if (t.changed) R.string.net_trust_changed_title else R.string.net_trust_title)
            .setMessage(msg)
            .setPositiveButton(R.string.net_trust) { _, _ -> onTrust() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun askShare(onName: (String) -> Unit) {
        val input = EditText(act)
        input.setSingleLine()
        input.setHint(R.string.net_share_hint)
        val box = LinearLayout(act)
        box.setPadding(px(22), px(8), px(22), 0)
        box.addView(input, LinearLayout.LayoutParams(-1, -2))
        MaterialAlertDialogBuilder(act)
            .setTitle(R.string.net_share_title)
            .setMessage(R.string.net_share_msg)
            .setView(box)
            .setPositiveButton(R.string.net_connect) { _, _ ->
                val n = input.text.toString().trim().trim('/', '\\')
                if (n.isNotEmpty()) onName(n)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------------------------------------------------------- 3. složky

    /** Přidat další složku z uloženého úložiště – bez nového přihlašování. */
    fun addFolder(s: NetServer) = connect(s, false) { fs -> browse(s, fs, first = false) }

    /** Vyloučit podsložku na úložišti. */
    fun exclude(s: NetServer, onPick: (String) -> Unit) = connect(s, false) { fs ->
        pick(s, fs, R.string.excl_browse_title, saveServer = false) { onPick(it) }
    }

    private fun browse(s: NetServer, fs: RemoteFs, first: Boolean) =
        pick(s, fs, R.string.net_browse_title, saveServer = true) { f ->
            onFolder(f)
            if (first) onChanged()
        }

    private fun pick(s: NetServer, fs: RemoteFs, title: Int, saveServer: Boolean, onPicked: (String) -> Unit) {
        val name = s.displayName
        // Samba bez pevné sdílené složky: na začátku seznam sdílených složek
        val roots: List<FolderBrowser.Node> = if (s.type == NetServer.SMB && s.share.isBlank()) {
            act.lifecycleScope.launch {
                val shares = withContext(Dispatchers.IO) {
                    try {
                        fs.list("/")
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
                FolderBrowser(
                    act, shares.map { FolderBrowser.NetNode(fs, "/" + it.name, it.name, name + "/" + it.name) },
                    true, title, onClose = { closeLater(fs) },
                ) { node -> picked(s, node, saveServer, onPicked) }.show()
            }
            return
        } else listOf(FolderBrowser.NetNode(fs, "/", name, name))
        FolderBrowser(act, roots, true, title, onClose = { closeLater(fs) }) { node ->
            picked(s, node, saveServer, onPicked)
        }.show()
    }

    private fun picked(s: NetServer, node: FolderBrowser.Node, saveServer: Boolean, onPicked: (String) -> Unit) {
        if (node !is FolderBrowser.NetNode) return
        if (saveServer) NetStore.save(act, s)
        onPicked(Net.make(s.id, node.path))
    }

    private fun closeLater(fs: RemoteFs) {
        act.lifecycleScope.launch(Dispatchers.IO) {
            try {
                fs.close()
            } catch (e: Exception) {
            }
        }
    }
}

/** Hledání NASů a SSH serverů v lokální síti (Bonjour / mDNS). */
private class Discovery(ctx: Context, private val onFound: (String, String, Int, Boolean) -> Unit) {
    private val nsd = ctx.getSystemService(NsdManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<NsdManager.DiscoveryListener>()
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private val seen = HashSet<String>()
    @Volatile private var stopped = false

    fun start() {
        for (type in listOf("_smb._tcp.", "_sftp-ssh._tcp.")) {
            val l = object : NsdManager.DiscoveryListener {
                override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {}
                override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {}
                override fun onDiscoveryStarted(serviceType: String?) {}
                override fun onDiscoveryStopped(serviceType: String?) {}
                override fun onServiceLost(serviceInfo: NsdServiceInfo?) {}
                override fun onServiceFound(info: NsdServiceInfo?) {
                    if (info == null) return
                    main.post {
                        queue.addLast(info)
                        next()
                    }
                }
            }
            try {
                nsd?.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l)
                listeners.add(l)
            } catch (e: Exception) {
            }
        }
    }

    /** Zjišťovat adresy po jedné (Android víc najednou neumí). */
    @Suppress("DEPRECATION")
    private fun next() {
        if (resolving || stopped) return
        val info = queue.removeFirstOrNull() ?: return
        resolving = true
        try {
            nsd?.resolveService(info, object : NsdManager.ResolveListener {
                override fun onResolveFailed(serviceInfo: NsdServiceInfo?, errorCode: Int) {
                    main.post { resolving = false; next() }
                }

                override fun onServiceResolved(si: NsdServiceInfo?) {
                    main.post {
                        resolving = false
                        val addr = si?.host
                        if (si != null && addr is Inet4Address && !stopped) {
                            val smb = si.serviceType?.contains("smb") == true
                            val host = addr.hostAddress ?: ""
                            if (seen.add("$host|$smb")) onFound(si.serviceName ?: host, host, si.port, smb)
                        }
                        next()
                    }
                }
            })
        } catch (e: Exception) {
            resolving = false
        }
    }

    fun stop() {
        stopped = true
        for (l in listeners) try {
            nsd?.stopServiceDiscovery(l)
        } catch (e: Exception) {
        }
        listeners.clear()
    }
}
