package cz.fif.findinfiles

import android.text.InputType
import android.view.View
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import okhttp3.HttpUrl.Companion.toHttpUrl
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Přidání složky ze síťového úložiště: výběr / zadání úložiště → připojení → výběr složky.
 * [onAdded] dostane složku ve tvaru "net:<id>:/cesta".
 */
class NetSetup(private val act: AppCompatActivity, private val onAdded: (String) -> Unit) {
    private val dp = act.resources.displayMetrics.density

    fun start() {
        val servers = NetStore.all(act)
        if (servers.isEmpty()) {
            form(null)
            return
        }
        // už uložené úložiště (heslo není potřeba zadávat znovu), nebo nové
        val names = servers.map { (it.name.ifBlank { it.host }) + "  (" + typeName(it.type) + ")" } + act.getString(R.string.net_new)
        MaterialAlertDialogBuilder(act)
            .setTitle(R.string.net_choose_title)
            .setItems(names.toTypedArray()) { _, i ->
                if (i < servers.size) connect(servers[i]) else form(null)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun typeName(t: String) = if (t == NetServer.SMB) "SMB" else "WebDAV"

    /** Pole s plovoucím popiskem; u hesla tečky a oko pro zobrazení. */
    private fun field(hint: Int, type: Int = InputType.TYPE_CLASS_TEXT, password: Boolean = false): Pair<TextInputLayout, TextInputEditText> {
        val til = TextInputLayout(act)
        til.hint = act.getString(hint)
        val et = TextInputEditText(til.context)
        et.setSingleLine() // před inputType – jinak by u hesla zrušilo tečky
        et.inputType = type
        til.addView(et, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        if (password) til.endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
        til.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = (8 * dp).toInt() }
        return til to et
    }

    private fun form(prev: NetServer?, error: String? = null) {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            val p = (22 * dp).toInt()
            setPadding(p, (6 * dp).toInt(), p, 0)
        }
        val group = RadioGroup(act).apply { orientation = RadioGroup.HORIZONTAL }
        val smb = RadioButton(act).apply { id = View.generateViewId(); setText(R.string.net_type_smb) }
        val dav = RadioButton(act).apply { id = View.generateViewId(); setText(R.string.net_type_dav) }
        group.addView(smb)
        group.addView(dav)
        val note = TextView(act).apply {
            textSize = 12.5f
            alpha = 0.7f
        }
        val (nameL, name) = field(R.string.net_name_hint)
        val (hostL, host) = field(R.string.net_host_smb_hint, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        val (portL, port) = field(R.string.net_port_hint, InputType.TYPE_CLASS_NUMBER)
        portL.helperText = act.getString(R.string.net_port_help)
        val (shareL, share) = field(R.string.net_share_hint)
        val (userL, user) = field(R.string.net_user_hint)
        val (passL, pass) = field(R.string.net_pass_hint, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD, password = true)
        val err = TextView(act).apply {
            setTextColor(act.getColor(R.color.danger))
            text = error ?: ""
            visibility = if (error == null) View.GONE else View.VISIBLE
            setPadding(0, (10 * dp).toInt(), 0, 0)
        }
        for (v in listOf(group, note, nameL, hostL, portL, shareL, userL, passL, err)) box.addView(v)

        fun applyType() {
            val isSmb = group.checkedRadioButtonId == smb.id
            shareL.visibility = if (isSmb) View.VISIBLE else View.GONE
            hostL.hint = act.getString(if (isSmb) R.string.net_host_smb_hint else R.string.net_host_dav_hint)
            portL.placeholderText = if (isSmb) "445" else "443"
            note.setText(if (isSmb) R.string.net_type_smb_note else R.string.net_type_dav_note)
        }
        group.setOnCheckedChangeListener { _, _ -> applyType() }
        group.check(if (prev?.type == NetServer.DAV) dav.id else smb.id)
        if (prev != null) {
            name.setText(prev.name)
            // port zvlášť, ať je hned vidět
            if (prev.type == NetServer.SMB) {
                host.setText(prev.host.substringBefore(':'))
                port.setText(prev.host.substringAfter(':', ""))
            } else {
                val u = try {
                    prev.host.toHttpUrl()
                } catch (e: Exception) {
                    null
                }
                if (u != null && u.port != 443) {
                    host.setText(prev.host.replaceFirst(":" + u.port, ""))
                    port.setText(u.port.toString())
                } else host.setText(prev.host)
            }
            share.setText(prev.share)
            user.setText(prev.user)
            pass.setText(prev.pass)
        }
        applyType()

        val dialog = MaterialAlertDialogBuilder(act)
            .setTitle(R.string.net_add_title)
            .setView(android.widget.ScrollView(act).apply { addView(box) })
            .setPositiveButton(R.string.net_connect, null)
            .setNegativeButton(R.string.cancel, null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val isSmb = group.checkedRadioButtonId == smb.id
                var h = host.text.toString().trim()
                val p = port.text.toString().trim().toIntOrNull()?.takeIf { it in 1..65535 }
                var problem: String? = null
                if (isSmb) {
                    h = h.removePrefix("smb://").removePrefix("\\\\").trim('/', '\\')
                    if (p != null) h = h.substringBefore(':') + ":" + p
                } else {
                    if (!h.contains("://")) h = "https://$h"
                    if (!h.startsWith("https://", ignoreCase = true)) problem = act.getString(R.string.net_err_https)
                    else if (p != null) {
                        h = try {
                            h.toHttpUrl().newBuilder().port(p).build().toString().trimEnd('/')
                        } catch (e: Exception) {
                            h
                        }
                    }
                }
                if (problem == null) problem = when {
                    host.text.isNullOrBlank() -> act.getString(R.string.net_err_host)
                    port.text?.isNotBlank() == true && p == null -> act.getString(R.string.net_err_port)
                    isSmb && share.text.isNullOrBlank() -> act.getString(R.string.net_err_share_empty)
                    else -> null
                }
                if (problem != null) {
                    err.text = problem
                    err.visibility = View.VISIBLE
                    return@setOnClickListener
                }
                val s = NetServer(
                    prev?.id ?: NetServer.newId(),
                    if (isSmb) NetServer.SMB else NetServer.DAV,
                    name.text.toString().trim(),
                    h,
                    share.text.toString().trim().trim('/', '\\'),
                    user.text.toString().trim(),
                    pass.text.toString(),
                )
                dialog.dismiss()
                connect(s)
            }
        }
        dialog.show()
    }

    private fun connect(s: NetServer) {
        val progress = MaterialAlertDialogBuilder(act)
            .setMessage(R.string.net_connecting)
            .setCancelable(false)
            .show()
        act.lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) {
                try {
                    val fs = Net.connect(s)
                    try {
                        fs.list("/") // ověřit, že jde číst
                        Result.success(fs)
                    } catch (e: Throwable) {
                        fs.close()
                        throw e
                    }
                } catch (e: Throwable) {
                    Result.failure<RemoteFs>(e)
                }
            }
            progress.dismiss()
            res.onSuccess { fs -> browse(s, fs) }
            res.onFailure { e ->
                val msg = Net.errorText(act, e)
                form(s, msg)
            }
        }
    }

    private fun browse(s: NetServer, fs: RemoteFs) {
        val title = s.name.ifBlank { if (s.type == NetServer.SMB) s.share else s.host.substringAfter("://").substringBefore('/') }
        val root = FolderBrowser.NetNode(fs, "/", title, title)
        FolderBrowser(act, listOf(root), true, R.string.net_browse_title, onPick = { node ->
            if (node is FolderBrowser.NetNode) {
                // název pro zobrazení: zadaný, jinak sdílená složka / adresa
                NetStore.save(act, s.copy(name = title))
                onAdded(Net.make(s.id, node.path))
            }
        }, onClose = {
            act.lifecycleScope.launch(Dispatchers.IO) { fs.close() }
        }).show()
    }
}
