package cz.fif.findinfiles

import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Přidání složky ze síťového úložiště: výběr / zadání úložiště → připojení → výběr složky.
 * [onAdded] dostane složku ve tvaru "net:<id>:/cesta".
 */
class NetSetup(private val act: AppCompatActivity, private val onAdded: (String) -> Unit) {
    private val dp = act.resources.displayMetrics.density

    fun start() {
        val servers = NetStore.all(act)
        if (servers.isEmpty()) {
            form(null)
            return
        }
        // už uložené úložiště (heslo není potřeba zadávat znovu), nebo nové
        val names = servers.map { (it.name.ifBlank { it.host }) + "  (" + typeName(it.type) + ")" } + act.getString(R.string.net_new)
        MaterialAlertDialogBuilder(act)
            .setTitle(R.string.net_choose_title)
            .setItems(names.toTypedArray()) { _, i ->
                if (i < servers.size) connect(servers[i]) else form(null)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun typeName(t: String) = if (t == NetServer.SMB) "SMB" else "WebDAV"

    private fun field(hint: Int, type: Int = InputType.TYPE_CLASS_TEXT): EditText = EditText(act).apply {
        setHint(hint)
        inputType = type
        setSingleLine()
    }

    private fun form(prev: NetServer?, error: String? = null) {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            val p = (22 * dp).toInt()
            setPadding(p, (6 * dp).toInt(), p, 0)
        }
        val group = RadioGroup(act).apply { orientation = RadioGroup.HORIZONTAL }
        val smb = RadioButton(act).apply { id = View.generateViewId(); setText(R.string.net_type_smb) }
        val dav = RadioButton(act).apply { id = View.generateViewId(); setText(R.string.net_type_dav) }
        group.addView(smb)
        group.addView(dav)
        val note = TextView(act).apply {
            textSize = 12.5f
            alpha = 0.7f
            setPadding(0, 0, 0, (6 * dp).toInt())
        }
        val name = field(R.string.net_name_hint)
        val host = field(R.string.net_host_smb_hint, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        val share = field(R.string.net_share_hint)
        val user = field(R.string.net_user_hint)
        val pass = field(R.string.net_pass_hint, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val err = TextView(act).apply {
            setTextColor(act.getColor(R.color.danger))
            text = error ?: ""
            visibility = if (error == null) View.GONE else View.VISIBLE
            setPadding(0, (8 * dp).toInt(), 0, 0)
        }
        for (v in listOf(group, note, name, host, share, user, pass, err)) box.addView(v)

        fun applyType() {
            val isSmb = group.checkedRadioButtonId == smb.id
            share.visibility = if (isSmb) View.VISIBLE else View.GONE
            host.setHint(if (isSmb) R.string.net_host_smb_hint else R.string.net_host_dav_hint)
            note.setText(if (isSmb) R.string.net_type_smb_note else R.string.net_type_dav_note)
        }
        group.setOnCheckedChangeListener { _, _ -> applyType() }
        group.check(if (prev?.type == NetServer.DAV) dav.id else smb.id)
        if (prev != null) {
            name.setText(prev.name)
            host.setText(prev.host)
            share.setText(prev.share)
            user.setText(prev.user)
            pass.setText(prev.pass)
        }
        applyType()

        val dialog = MaterialAlertDialogBuilder(act)
            .setTitle(R.string.net_add_title)
            .setView(android.widget.ScrollView(act).apply { addView(box) })
            .setPositiveButton(R.string.net_connect, null)
            .setNegativeButton(R.string.cancel, null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val isSmb = group.checkedRadioButtonId == smb.id
                var h = host.text.toString().trim()
                if (isSmb) h = h.removePrefix("smb://").removePrefix("\\\\").trim('/', '\\')
                else if (!h.contains("://")) h = "https://$h"
                val problem = when {
                    h.isEmpty() -> act.getString(R.string.net_err_host)
                    isSmb && share.text.isBlank() -> act.getString(R.string.net_err_share_empty)
                    !isSmb && !h.startsWith("https://", ignoreCase = true) -> act.getString(R.string.net_err_https)
                    else -> null
                }
                if (problem != null) {
                    err.text = problem
                    err.visibility = View.VISIBLE
                    return@setOnClickListener
                }
                val s = NetServer(
                    prev?.id ?: NetServer.newId(),
                    if (isSmb) NetServer.SMB else NetServer.DAV,
                    name.text.toString().trim(),
                    h,
                    share.text.toString().trim().trim('/', '\\'),
                    user.text.toString().trim(),
                    pass.text.toString(),
                )
                dialog.dismiss()
                connect(s)
            }
        }
        dialog.show()
    }

    private fun connect(s: NetServer) {
        val progress = MaterialAlertDialogBuilder(act)
            .setMessage(R.string.net_connecting)
            .setCancelable(false)
            .show()
        act.lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) {
                try {
                    val fs = Net.connect(s)
                    try {
                        fs.list("/") // ověřit, že jde číst
                        Result.success(fs)
                    } catch (e: Throwable) {
                        fs.close()
                        throw e
                    }
                } catch (e: Throwable) {
                    Result.failure<RemoteFs>(e)
                }
            }
            progress.dismiss()
            res.onSuccess { fs -> browse(s, fs) }
            res.onFailure { e ->
                val msg = Net.errorText(act, e)
                form(s, msg)
            }
        }
    }

    private fun browse(s: NetServer, fs: RemoteFs) {
        val title = s.name.ifBlank { if (s.type == NetServer.SMB) s.share else s.host.substringAfter("://").substringBefore('/') }
        val root = FolderBrowser.NetNode(fs, "/", title, title)
        FolderBrowser(act, listOf(root), true, R.string.net_browse_title, onPick = { node ->
            if (node is FolderBrowser.NetNode) {
                // název pro zobrazení: zadaný, jinak sdílená složka / adresa
                NetStore.save(act, s.copy(name = title))
                onAdded(Net.make(s.id, node.path))
            }
        }, onClose = {
            act.lifecycleScope.launch(Dispatchers.IO) { fs.close() }
        }).show()
    }
}
